#include <iostream>
#include <vector>
#include<ctime>
#include<sstream>

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include "Gui.h"

int main(){
    //delta time
    sf::Clock dtClock;
    float dt;
    //mouse pos
    sf::Vector2i mousePosWindow;

    //Create window
    sf::RenderWindow window(sf::VideoMode(1000, 800), "gui elements");
    window.setVerticalSyncEnabled(true);
    window.setFramerateLimit(60);

    //Init Font
        sf::Font font;
        if(!font.loadFromFile("../../src/fonts/Roboto-BlackItalic.ttf")){
            std::cout << "Error::Game::INITFONTS Failed to load font!" << "\n";
        }

    //Init ui dictonary
    gui::UIDictionary<gui::UIElement*> ui;
    gui::UIDictionary<gui::Layout*> layouts;
  
    //Adding a button without using template
    std::string text = "btn";
    int char_size = 26; 
    //Defualt button
    ui.add("BTN1-1", new gui::Button(100.f,10.f,104.f,37.f,font,"BTN", char_size));
    ui.add("BTN2-1", new gui::Button(220.f,10.f,104.f,37.f,font,"BTN", char_size));
    ui.add("BTN3-1", new gui::Button(340.f,10.f,104.f,37.f,font,"BTN", char_size));

    //Createing a button to use as a template
    gui::Button templateButton(250.f,100.f,150.f,40.f,
        font,text, char_size,
        sf::Color(170,70,70,230), sf::Color(250,150,150,255), sf::Color(120,20,20,50),
        sf::Color(70,70,170,230), sf::Color(150,150,250,255), sf::Color(20,20,120,50)
    );

    //Adding buttons using the template

    ui.add("BUTTON2", new gui::Button(100,90,120,60,"btn2",&templateButton));
    ui.add("BUTTON3", new gui::Button(250,90,120,60,"btn3",&templateButton));
    ui.add("BUTTON4", new gui::Button(400,90,120,60,"btn4",&templateButton));

    //Adding IButton
    sf::Texture btnTex1;
    sf::Texture btnTex2;
    sf::Texture btnTex3;
    btnTex1.loadFromFile("../../src/images/Button1.png");
    btnTex2.loadFromFile("../../src/images/Button2.png");
    btnTex3.loadFromFile("../../src/images/Button3.png");
    

    layouts.add("LAYOUT0",new gui::Layout(500,200,"horiz_size",50,10,50));
    ui.add("IButton1", new gui::IButton(100,100,btnTex1,btnTex2,btnTex3));
    ui.add("IButton2", new gui::IButton(100,100,btnTex1,btnTex2,btnTex3));

    layouts.at("LAYOUT0")->addElement(ui.at("IButton1"));
    layouts.at("LAYOUT0")->addElement(ui.at("IButton2"));

    layouts.at("LAYOUT0")->calcPos();

    //Adding DropDownList
    layouts.add("LAYOUT1",new gui::Layout(100,250,"horiz_size",100,10));
    layouts.add("LAYOUT11",new gui::Layout(700,550,"vert_size",50,10));
    std::string list[5] = {"option 1","option 2","option 3","option 4","option 5"};

    ui.add("DROPDOWN1", new gui::DropDownList(100,200,100,50,list,5,&templateButton));
    ui.add("DROPDOWN2", new gui::DropDownList(300,200,150,50,list,5,&templateButton));
    ui.add("DROPDOWN3", new gui::DropDownList(300,200,150,50,list,5,&templateButton));
    ui.add("DROPDOWN4", new gui::DropDownList(300,200,150,50,list,5,&templateButton));

    layouts.at("LAYOUT1")->addElement(ui.at("DROPDOWN1"));
    layouts.at("LAYOUT1")->addElement(ui.at("DROPDOWN2"));
    layouts.at("LAYOUT11")->addElement(ui.at("DROPDOWN3"));
    layouts.at("LAYOUT11")->addElement(ui.at("DROPDOWN4"));

    layouts.at("LAYOUT1")->calcPos();
    layouts.at("LAYOUT11")->calcPos();

    //Adding CheckBox
    layouts.add("LAYOUT2",new gui::Layout(80,350,"horiz_size",40,10,40));
    layouts.add("LAYOUT22",new gui::Layout(400,350,"vert_size",40,10,40));

    ui.add("CHECKBOX1", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX2", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX3", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX4", new gui::CheckBox(0,0,20,font));

    layouts.at("LAYOUT2")->addElement(ui.at("CHECKBOX1"));
    layouts.at("LAYOUT2")->addElement(ui.at("CHECKBOX2"));

    layouts.at("LAYOUT22")->addElement(ui.at("CHECKBOX3"));
    layouts.at("LAYOUT22")->addElement(ui.at("CHECKBOX4"));

    layouts.at("LAYOUT2")->calcPos();
    layouts.at("LAYOUT22")->calcPos();

    //Adding ToggleSwitch
    layouts.add("LAYOUT3",new gui::Layout(100,450,"horiz_size",80,10));
    layouts.add("LAYOUT33",new gui::Layout(450,350,"vert_size",40,10));

    ui.add("TOGGLE1", new gui::ToggleSwitch(0,0,80,30,font));
    ui.add("TOGGLE2", new gui::ToggleSwitch(0,0,120,30,font));
    ui.add("TOGGLE3", new gui::ToggleSwitch(0,0,80,30,font));
    ui.add("TOGGLE4", new gui::ToggleSwitch(0,0,80,30,font));

    layouts.at("LAYOUT3")->addElement(ui.at("TOGGLE1"));
    layouts.at("LAYOUT3")->addElement(ui.at("TOGGLE2"));

    layouts.at("LAYOUT33")->addElement(ui.at("TOGGLE3"));
    layouts.at("LAYOUT33")->addElement(ui.at("TOGGLE4"));

    layouts.at("LAYOUT3")->calcPos();
    layouts.at("LAYOUT33")->calcPos();

    //Adding Slider
    layouts.add("LAYOUT4",new gui::Layout(100,550,"horiz_size",100,10));
    layouts.add("LAYOUT44",new gui::Layout(600,350,"vert_size",20,20));

    ui.add("SLIDER1", new gui::Slider(0,0,50,10,sf::Color::Blue,0,100,50));
    ui.add("SLIDER2", new gui::Slider(0,0,50,10,sf::Color::Blue,0,100,50));
    ui.add("SLIDER3", new gui::Slider(0,0,50,10,sf::Color::Blue,0,100,50));
    ui.add("SLIDER4", new gui::Slider(0,0,50,10,sf::Color::Blue,0,100,50));

    layouts.at("LAYOUT4")->addElement(ui.at("SLIDER1"));
    layouts.at("LAYOUT4")->addElement(ui.at("SLIDER2"));
    layouts.at("LAYOUT44")->addElement(ui.at("SLIDER3"));
    layouts.at("LAYOUT44")->addElement(ui.at("SLIDER4"));

    layouts.at("LAYOUT4")->calcPos();
    layouts.at("LAYOUT44")->calcPos();

    //Adding Radio list
    layouts.add("LAYOUT5",new gui::Layout(100,650,"horiz_size",50,10,50));
    layouts.add("LAYOUT55",new gui::Layout(700,350,"vert_size",50,10,50));

    ui.add("RADIO1", new gui::RadioList(0,0,10,50,font, list,5));
    ui.add("RADIO2", new gui::RadioList(0,0,20,50,font, list,5));
    ui.add("RADIO3", new gui::RadioList(0,0,20,50,font, list,5));
    ui.add("RADIO4", new gui::RadioList(0,0,20,50,font, list,5));

    layouts.at("LAYOUT5")->addElement(ui.at("RADIO1"));
    layouts.at("LAYOUT5")->addElement(ui.at("RADIO2"));
    layouts.at("LAYOUT55")->addElement(ui.at("RADIO3"));
    layouts.at("LAYOUT55")->addElement(ui.at("RADIO4"));

    layouts.at("LAYOUT5")->calcPos();
    layouts.at("LAYOUT55")->calcPos();

    //Adding CheckBox
    layouts.add("LAYOUT7",new gui::Layout(700,100,"horiz_size",20,10,20));
    layouts.add("LAYOUT77",new gui::Layout(400,200,"horiz_size",20,10,20));
    layouts.add("LAYOUT777",new gui::Layout(700,100,"vert_size",0,30,0));

    ui.add("CHECKBOX21", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX22", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX23", new gui::CheckBox(0,0,20,font));
    ui.add("CHECKBOX24", new gui::CheckBox(0,0,20,font));

    layouts.at("LAYOUT7")->addElement(ui.at("CHECKBOX21"));
    layouts.at("LAYOUT7")->addElement(ui.at("CHECKBOX22"));

    layouts.at("LAYOUT77")->addElement(ui.at("CHECKBOX23"));
    layouts.at("LAYOUT77")->addElement(ui.at("CHECKBOX24"));

    layouts.at("LAYOUT777")->addElement(layouts.at("LAYOUT7"));
    layouts.at("LAYOUT777")->addElement(layouts.at("LAYOUT77"));

    layouts.at("LAYOUT7")->calcPos();
    layouts.at("LAYOUT77")->calcPos();
    layouts.at("LAYOUT777")->calcPos();
    

    //Create event variable
    sf::Event event;

    //-------------------------Main loop----------------------------

    while(window.isOpen()){
        //reset delta time
        dt = dtClock.restart().asSeconds();
        //update mouse pos
        mousePosWindow = sf::Mouse::getPosition(window);
        
       // check all the window's events that were triggered since the last iteration of the loop
        while (window.pollEvent(event))
        {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
                
                window.close();
        }

        //Updateing
        ui.update(mousePosWindow, dt);

        //Rendering
        window.clear();
        ui.render(window);
        window.display();
        
    }

    ui.clear();
    return 0;
}


