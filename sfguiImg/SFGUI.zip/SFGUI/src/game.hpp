#pragma once

#include <iostream>
#include <vector>
#include<ctime>
#include<sstream>

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>

#include "Gui.h"


/*
    class that acts as the game engin.
*/
class Game
{
    private:
    //Variables
    //Window
    sf::RenderWindow* window;
    sf::VideoMode videoMode;
    sf::Event ev;

    //Mouse positions
    sf::Vector2i mousePosWindow;
    sf::Vector2f mousePosView;

    //Game Logic
    bool endGame;
    unsigned points;
    int health;
 
    bool mouseHeld;
    sf::Clock dtClock;
    float dt;

    //Resources
    sf::Font font;

    //Text
    sf::Text uiText;

    //Button Textures 
    sf::Texture idleTex;
    sf::Texture hoverTex;
    sf::Texture activeTex;

    //UI Elements
    //std::map<std::string, gui::UIElement*> ui;
    gui::UIDictionary<gui::UIElement*> ui;
    gui::UIDictionary<gui::Layout*> layouts;

  


  

    //private functions
    void initVariables();
    void initWindow();
    void initFonts();
    void initGui();

    public:
    // constructors / destructors
    Game();
    virtual ~Game();

    //Accessors
    const bool running() const;
    const bool getEndGame() const;
    

    // Functions

    void pollEvents();
    void updateMousePositions();
 
    void updateGui();
    
    void updateDT();
    void update();

    void renderGui(sf::RenderTarget& target);
    void render();
};