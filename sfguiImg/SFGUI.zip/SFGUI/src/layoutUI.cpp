#include <iostream>
#include <vector>
#include<ctime>
#include<sstream>

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include "Gui.h"

#define RED sf::Color(255,55,55,255)



int main(){
    //delta time
    sf::Clock dtClock;
    float dt;
    //mouse pos
    sf::Vector2i mousePosWindow;

    //Create window
    sf::VideoMode vm(1000,700);
    sf::RenderWindow window(vm, "gui elements");
    window.setVerticalSyncEnabled(true);
    window.setFramerateLimit(60);
    

    //Init Font
        sf::Font font;
        if(!font.loadFromFile("../../src/fonts/Roboto-BlackItalic.ttf")){
            std::cout << "Error::Game::INITFONTS Failed to load font!" << "\n";
        }

    //Init Background
    sf::RectangleShape section1Bg;
    sf::RectangleShape section2Bg;
    sf::RectangleShape section2BottomHalve;
    sf::RectangleShape section3Bg;
    sf::RectangleShape section4Bg;

    section1Bg.setPosition(0,0);
    section1Bg.setSize(sf::Vector2f(vm.width/2, gui::p2pY(61.8,vm) ));
    section1Bg.setFillColor(sf::Color(255,255,255,255));

    section2Bg.setPosition(0,gui::p2pY(61.8,vm));
    section2Bg.setSize(sf::Vector2f(vm.width/2, gui::p2pY(38.2,vm)));
    section2Bg.setFillColor(sf::Color(223,206,10,255));

    section2BottomHalve.setPosition(0,gui::p2pY(61.8,vm));
    section2BottomHalve.setSize(sf::Vector2f(vm.width/2, gui::p2pY(38.2,vm)/2));
    section2BottomHalve.setFillColor(sf::Color(243,246,51,255));

    section3Bg.setPosition(vm.width/2,0);
    section3Bg.setSize(sf::Vector2f(vm.width/2,gui::p2pY(38.2,vm)));
    section3Bg.setFillColor(sf::Color(255,55,55,255));
    

    section4Bg.setPosition(vm.width/2,gui::p2pY(38.2,vm));
    section4Bg.setSize(sf::Vector2f(vm.width/2, gui::p2pY(61.8,vm)));
    section4Bg.setFillColor(sf::Color(0,0,0,255));

    //Init ui dictonary
    gui::UIDictionary<gui::UIElement*> ui;
    gui::UIDictionary<gui::Layout*> layouts;

    //Adding a button without using template
    std::string text = "btn";
    int char_size = 26; 
   

    //Createing a button to use as a template
    gui::Button templateButton(250.f,100.f,150.f,40.f,
        font,text, char_size,
        sf::Color(170,70,70,230), sf::Color(250,150,150,255), sf::Color(120,20,20,50),
        sf::Color(70,70,170,230), sf::Color(150,150,250,255), sf::Color(20,20,120,50)
    );

    //--------------------------------section 1---------------------------------
    sf::IntRect sec1Rect;
    sec1Rect.left = section1Bg.getPosition().x;
    sec1Rect.top = section1Bg.getPosition().y; 
    sec1Rect.width = section1Bg.getSize().x;
    sec1Rect.height = section1Bg.getSize().y;

    ui.add("SECTION1TITLE", new gui::Text( 0,0,font,32,"Diffrent Layout",sf::Color(0,0,0,255) ) );
    gui::align("center_x",sec1Rect,ui.at("SECTION1TITLE"));

    //Adding buttons using the template
    layouts.add("LAYOUT1", new gui::Layout(20.f,100.f,"horiz_size",102.f,50.f));
    ui.add("BUTTON2", new gui::Button(300,100,120,37,font,"btn",26));
    ui.add("BUTTON3", new gui::Button(300,200,120,37,font,"btn",26));
    ui.add("BUTTON4", new gui::Button(300,200,120,37,font,"btn",26));

    layouts.at("LAYOUT1")->addElement(ui.at("BUTTON2"));
    layouts.at("LAYOUT1")->addElement(ui.at("BUTTON3"));
    layouts.at("LAYOUT1")->addElement(ui.at("BUTTON4"));
    layouts.at("LAYOUT1")->calcPos();

    //Adding buttons using the template
    layouts.add("LAYOUT2", new gui::Layout(20.f,200.f,"horiz_grid",120.f));
    ui.add("BUTTON5", new gui::Button(300,100,100,37,font,"btn",26));
    ui.add("BUTTON6", new gui::Button(300,200,60,37,font,"btn",26));
    ui.add("BUTTON7", new gui::Button(300,200,40,37,font,"btn",26));
    ui.add("BUTTON8", new gui::Button(300,200,100,37,font,"btn",26));

    layouts.at("LAYOUT2")->addElement(ui.at("BUTTON5"));
    layouts.at("LAYOUT2")->addElement(ui.at("BUTTON6"));
    layouts.at("LAYOUT2")->addElement(ui.at("BUTTON7"));
    layouts.at("LAYOUT2")->addElement(ui.at("BUTTON8"));
    layouts.at("LAYOUT2")->calcPos();

    //Adding buttons using the template
    layouts.add("LAYOUT3", new gui::Layout(20.f,300.f,"horiz_grid",120.f));
    ui.add("BUTTON9", new gui::Button(300,100,60,37,font,"btn",26));
    ui.add("BUTTON10", new gui::Button(300,200,40,37,font,"btn",26));
    ui.add("BUTTON11", new gui::Button(300,200,100,37,font,"btn",26));
    ui.add("BUTTON12", new gui::Button(300,200,60,37,font,"btn",26));

    layouts.at("LAYOUT3")->addElement(ui.at("BUTTON9"));
    layouts.at("LAYOUT3")->addElement(ui.at("BUTTON10"));
    layouts.at("LAYOUT3")->addElement(ui.at("BUTTON11"));
    layouts.at("LAYOUT3")->addElement(ui.at("BUTTON12"));
    layouts.at("LAYOUT3")->calcPos();

    //Layout 4
    layouts.add("LAYOUT4", new gui::Layout(20.f,350.f,"horiz_pad",40.f));
    ui.add("BUTTON13", new gui::Button(300,100,100,37,font,"btn2",26));
    ui.add("BUTTON14", new gui::Button(300,200,60,37,font,"btn2",26));
    ui.add("BUTTON15", new gui::Button(300,200,40,37,font,"btn2",26));
    ui.add("BUTTON16", new gui::Button(300,200,100,37,font,"btn2",26));

    layouts.at("LAYOUT4")->addElement(ui.at("BUTTON13"));
    layouts.at("LAYOUT4")->addElement(ui.at("BUTTON14"));
    layouts.at("LAYOUT4")->addElement(ui.at("BUTTON15"));
    layouts.at("LAYOUT4")->addElement(ui.at("BUTTON16"));
    layouts.at("LAYOUT4")->calcPos();

    




    //--------------------------------section 2--------------------------------------
    //horizontal size layout
    layouts.add("LAYOUT2-1", new gui::Layout(520.f,100.f,"vert_size",40.f,10.f));
    ui.add("BUTTON2-1", new gui::Button(300,100,60,37,font,"btn",26));
    ui.add("BUTTON2-2", new gui::Button(300,200,60,37,font,"btn",26));
    ui.add("BUTTON2-3", new gui::Button(300,200,60,37,font,"btn",26));

    layouts.at("LAYOUT2-1")->addElement(ui.at("BUTTON2-1"));
    layouts.at("LAYOUT2-1")->addElement(ui.at("BUTTON2-2"));
    layouts.at("LAYOUT2-1")->addElement(ui.at("BUTTON2-3"));
    layouts.at("LAYOUT2-1")->calcPos();

    //horizontal grid layout
    layouts.add("LAYOUT2-2", new gui::Layout(720.f,100.f,"vert_grid",60.f));
    ui.add("BUTTON2-4", new gui::Button(300,100,60,50,font,"btn",26));
    ui.add("BUTTON2-5", new gui::Button(300,200,60,40,font,"btn",26));
    ui.add("BUTTON2-6", new gui::Button(300,200,60,30,font,"btn",26));

    layouts.at("LAYOUT2-2")->addElement(ui.at("BUTTON2-4"));
    layouts.at("LAYOUT2-2")->addElement(ui.at("BUTTON2-5"));
    layouts.at("LAYOUT2-2")->addElement(ui.at("BUTTON2-6"));
    layouts.at("LAYOUT2-2")->calcPos();

    layouts.add("LAYOUT2-3", new gui::Layout(620.f,100.f,"vert_grid",60.f));
    ui.add("BUTTON2-7", new gui::Button(300,100,60,30,font,"btn",26));
    ui.add("BUTTON2-8", new gui::Button(300,200,60,50,font,"btn",26));
    ui.add("BUTTON2-9", new gui::Button(300,200,60,40,font,"btn",26));

    layouts.at("LAYOUT2-3")->addElement(ui.at("BUTTON2-7"));
    layouts.at("LAYOUT2-3")->addElement(ui.at("BUTTON2-8"));
    layouts.at("LAYOUT2-3")->addElement(ui.at("BUTTON2-9"));
    layouts.at("LAYOUT2-3")->calcPos();

    //horizontal pad layout
    layouts.add("LAYOUT2-4", new gui::Layout(820.f,100.f,"vert_pad",30.f));
    ui.add("BUTTON2-11", new gui::Button(300,200,60,30,font,"vp2",26));
    ui.add("BUTTON2-12", new gui::Button(300,200,60,30,font,"vp3",26));
    ui.add("BUTTON2-13", new gui::Button(300,200,60,30,font,"vp3",26));

    layouts.at("LAYOUT2-4")->addElement(ui.at("BUTTON2-11"));
    layouts.at("LAYOUT2-4")->addElement(ui.at("BUTTON2-12"));
    layouts.at("LAYOUT2-4")->addElement(ui.at("BUTTON2-13"));
    layouts.at("LAYOUT2-4")->calcPos();

    //-------------------------------------------section 3------------------------------------

    layouts.add("LAYOUT3-1", new gui::Layout(50.f,500.f,"vert_pad",30.f));
    ui.add("BUTTON3-1", new gui::ToggleSwitch(50,500,80,30,font));
    ui.add("BUTTON3-2", new gui::ToggleSwitch(150,500,80,30,font));
    ui.add("BUTTON3-3", new gui::ToggleSwitch(250,500,80,30,font));

    layouts.at("LAYOUT3-1")->addElement(ui.at("BUTTON3-1"));
    layouts.at("LAYOUT3-1")->addElement(ui.at("BUTTON3-2"));
    layouts.at("LAYOUT3-1")->addElement(ui.at("BUTTON3-3"));

    sf::IntRect sec3Rect;
    sec3Rect.left = section2Bg.getPosition().x;
    sec3Rect.top = section2Bg.getPosition().y; 
    sec3Rect.width = section2Bg.getSize().x;
    sec3Rect.height = section2Bg.getSize().y;
    gui::align("center", sec3Rect, layouts.at("LAYOUT3-1"));
    // gui::align("top", sec3Rect, layouts.at("LAYOUT3-1"));
    // gui::align("bottom", sec3Rect, layouts.at("LAYOUT3-1"));
    // gui::align("center_x", sec3Rect, layouts.at("LAYOUT3-1"));
    // gui::align("center_y", sec3Rect, layouts.at("LAYOUT3-1"));
    gui::align("left", sec3Rect, layouts.at("LAYOUT3-1"));
    layouts.at("LAYOUT3-1")->calcPos();

    //-----------------------------------------------

    layouts.add("LAYOUT3-2", new gui::Layout(200.f,500.f,"vert_pad",30.f));
    ui.add("BUTTON3-4", new gui::ToggleSwitch(50,500,80,30,font));
    ui.add("BUTTON3-5", new gui::ToggleSwitch(150,500,80,30,font));
    ui.add("BUTTON3-6", new gui::ToggleSwitch(250,500,80,30,font));

    layouts.at("LAYOUT3-2")->addElement(ui.at("BUTTON3-4"));
    layouts.at("LAYOUT3-2")->addElement(ui.at("BUTTON3-5"));
    layouts.at("LAYOUT3-2")->addElement(ui.at("BUTTON3-6"));

    gui::align("center", sec3Rect, layouts.at("LAYOUT3-2"));
    // gui::align("top", sec3Rect, layouts.at("LAYOUT3-2"));
    // gui::align("left", sec3Rect, layouts.at("LAYOUT3-2"));
    gui::align("right", sec3Rect, layouts.at("LAYOUT3-2"));
    //gui::align("bottom", sec3Rect, layouts.at("LAYOUT3-2"));
    //gui::align("center_y", sec3Rect, layouts.at("LAYOUT3-2"));
    //gui::align("center_x", sec3Rect, layouts.at("LAYOUT3-2"));
    layouts.at("LAYOUT3-2")->calcPos();

    //---------------------------------------------
    layouts.add("LAYOUT3-3", new gui::Layout(200.f,500.f,"horiz_pad",30.f));
    ui.add("BUTTON3-7", new gui::Slider(200,500,100,10,sf::Color(100,100,100),0,100,10));
    ui.add("BUTTON3-8", new gui::Slider(200,550,100,10,sf::Color(100,100,100),0,100,90));
    
    layouts.at("LAYOUT3-3")->addElement(ui.at("BUTTON3-7"));
    layouts.at("LAYOUT3-3")->addElement(ui.at("BUTTON3-8"));

    gui::align("center", sec3Rect, layouts.at("LAYOUT3-3"));
    // gui::align("left", sec3Rect, layouts.at("LAYOUT3-3"));
    // gui::align("right", sec3Rect, layouts.at("LAYOUT3-3"));
    // gui::align("top", sec3Rect, layouts.at("LAYOUT3-3"));
     gui::align("bottom", sec3Rect, layouts.at("LAYOUT3-3"));
    // gui::align("center_x", sec3Rect, layouts.at("LAYOUT3-3"));
    // gui::align("center_y", sec3Rect, layouts.at("LAYOUT3-3"));
    
    layouts.at("LAYOUT3-3")->calcPos();

    //----------------------------------------
    layouts.add("LAYOUT3-4", new gui::Layout(30.f,500.f,"horiz_grid",15.f));
    ui.add("BUTTON3-9", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-11", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-12", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-13", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-14", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    layouts.at("LAYOUT3-4")->addElement(ui.at("BUTTON3-9"));
    layouts.at("LAYOUT3-4")->addElement(ui.at("BUTTON3-11"));
    layouts.at("LAYOUT3-4")->addElement(ui.at("BUTTON3-12"));
    layouts.at("LAYOUT3-4")->addElement(ui.at("BUTTON3-13"));
    layouts.at("LAYOUT3-4")->addElement(ui.at("BUTTON3-14"));

    //gui::align("center",sec3Rect,layouts.at("LAYOUT3-4"));
    gui::align("right",sec3Rect,layouts.at("LAYOUT3-4"));
    gui::align("left",sec3Rect,layouts.at("LAYOUT3-4"));
    gui::align("center_y",sec3Rect,layouts.at("LAYOUT3-4"));
    //gui::align("top",sec3Rect,layouts.at("LAYOUT3-4"));
    gui::align("center_x",sec3Rect,layouts.at("LAYOUT3-4"));


    layouts.at("LAYOUT3-4")->calcPos();

    //----------------------------------------
    layouts.add("LAYOUT3-5", new gui::Layout(30.f,450.f,"vert_grid",15.f));
    ui.add("BUTTON3-15", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-16", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    ui.add("BUTTON3-17", new gui::CheckBox(300,500,10,font,sf::Color(200,200,200,255),sf::Color(0,0,200,255),true));
    
    layouts.at("LAYOUT3-5")->addElement(ui.at("BUTTON3-15"));
    layouts.at("LAYOUT3-5")->addElement(ui.at("BUTTON3-16"));
    layouts.at("LAYOUT3-5")->addElement(ui.at("BUTTON3-17"));
   

 
    gui::align("right",sec3Rect,layouts.at("LAYOUT3-5"));
    gui::align("left",sec3Rect,layouts.at("LAYOUT3-5"));
    gui::align("bottom",sec3Rect,layouts.at("LAYOUT3-5"));
    gui::align("center",sec3Rect,layouts.at("LAYOUT3-5"));
 

    layouts.at("LAYOUT3-5")->calcPos();

    //----------------------------------------
    layouts.add("LAYOUT3-6", new gui::Layout(30.f,480.f,"horiz_size",50.f,15.f,20.f));
    ui.add("LAY3-6-BTN1", new gui::Button(0,0,80,20,font,"",12));
    ui.add("LAY3-6-BTN2", new gui::Button(0,0,80,20,font,"",12));

    layouts.at("LAYOUT3-6")->addElement(ui.at("LAY3-6-BTN1"));
    layouts.at("LAYOUT3-6")->addElement(ui.at("LAY3-6-BTN2"));

    gui::align("bottom",sec3Rect,layouts.at("LAYOUT3-6"));
    gui::align("top",sec3Rect,layouts.at("LAYOUT3-6"));
    gui::align("left",sec3Rect,layouts.at("LAYOUT3-6"));
    gui::move(5,5,layouts.at("LAYOUT3-6"));
    layouts.at("LAYOUT3-6")->calcPos();

    //----------------------------------------
    layouts.add("LAYOUT3-7", new gui::Layout(400.f,480.f,"vert_size",20.f,10.f,50.f));
    ui.add("LAY3-7-BTN1", new gui::Button(0,0,80,20,font,"",12));
    ui.add("LAY3-7-BTN2", new gui::Button(0,0,80,20,font,"",12));

    layouts.at("LAYOUT3-7")->addElement(ui.at("LAY3-7-BTN1"));
    layouts.at("LAYOUT3-7")->addElement(ui.at("LAY3-7-BTN2"));

    gui::align("top",sec3Rect,layouts.at("LAYOUT3-7"));
    gui::align("left",sec3Rect,layouts.at("LAYOUT3-7"));
    gui::align("right",sec3Rect,layouts.at("LAYOUT3-7"));
    gui::move(-5,5,layouts.at("LAYOUT3-7"));
    
    layouts.at("LAYOUT3-7")->calcPos();


    //-----------------------section 4--------------------------
    layouts.add("LAYOUT4-1",new gui::Layout(550,350,"horiz_grid",70));
    layouts.add("LAYOUT4-2",new gui::Layout(550,380,"horiz_grid",70));
    layouts.add("LAYOUT4-3",new gui::Layout(510,320,"vert_grid",50));

    ui.add("LAY4-1-BTN1", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-1-CHECK1", new gui::ToggleSwitch(0,0,50,20,font));

    ui.add("LAY4-1-BTN2", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-1-CHECK2", new gui::ToggleSwitch(0,0,50,20,font));

    layouts.at("LAYOUT4-1")->addElement(ui.at("LAY4-1-BTN1"));
    layouts.at("LAYOUT4-1")->addElement(ui.at("LAY4-1-CHECK1"));

    layouts.at("LAYOUT4-2")->addElement(ui.at("LAY4-1-BTN2"));
    layouts.at("LAYOUT4-2")->addElement(ui.at("LAY4-1-CHECK2"));

    layouts.at("LAYOUT4-3")->addElement(layouts.at("LAYOUT4-1"));
    layouts.at("LAYOUT4-3")->addElement(layouts.at("LAYOUT4-2"));

    
    layouts.at("LAYOUT4-1")->calcPos();
    layouts.at("LAYOUT4-2")->calcPos();
    layouts.at("LAYOUT4-3")->calcPos();

    //-------------------------------------------------------------------------
    layouts.add("LAYOUT4-4",new gui::Layout(650,350,"horiz_pad",20));
    layouts.add("LAYOUT4-5",new gui::Layout(550,380,"horiz_pad",20));
    layouts.add("LAYOUT4-6",new gui::Layout(700,320,"vert_pad",20));

    ui.add("LAY4-4-BTN1", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-4-CHECK1", new gui::ToggleSwitch(0,0,50,20,font));

    ui.add("LAY4-5-BTN2", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-5-CHECK2", new gui::ToggleSwitch(0,0,50,20,font));

    layouts.at("LAYOUT4-4")->addElement(ui.at("LAY4-4-BTN1"));
    layouts.at("LAYOUT4-4")->addElement(ui.at("LAY4-4-CHECK1"));

    layouts.at("LAYOUT4-5")->addElement(ui.at("LAY4-5-BTN2"));
    layouts.at("LAYOUT4-5")->addElement(ui.at("LAY4-5-CHECK2"));

    layouts.at("LAYOUT4-6")->addElement(layouts.at("LAYOUT4-4"));
    layouts.at("LAYOUT4-6")->addElement(layouts.at("LAYOUT4-5"));

    
    layouts.at("LAYOUT4-4")->calcPos();
    layouts.at("LAYOUT4-5")->calcPos();
    layouts.at("LAYOUT4-6")->calcPos();
    //----------------------------------------------------------------------
    layouts.add("LAYOUT4-7",new gui::Layout(650,350,"horiz_size",50,10,20));
    layouts.add("LAYOUT4-8",new gui::Layout(550,380,"horiz_size",50,10,20));
    layouts.add("LAYOUT4-9",new gui::Layout(850,320,"vert_size",20,10,50));

    ui.add("LAY4-7-BTN1", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-7-CHECK1", new gui::ToggleSwitch(0,0,50,20,font));

    ui.add("LAY4-8-BTN2", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-8-CHECK2", new gui::ToggleSwitch(0,0,50,20,font));

    layouts.at("LAYOUT4-7")->addElement(ui.at("LAY4-7-BTN1"));
    layouts.at("LAYOUT4-7")->addElement(ui.at("LAY4-7-CHECK1"));

    layouts.at("LAYOUT4-8")->addElement(ui.at("LAY4-8-BTN2"));
    layouts.at("LAYOUT4-8")->addElement(ui.at("LAY4-8-CHECK2"));

    layouts.at("LAYOUT4-9")->addElement(layouts.at("LAYOUT4-7"));
    layouts.at("LAYOUT4-9")->addElement(layouts.at("LAYOUT4-8"));

    
    layouts.at("LAYOUT4-7")->calcPos();
    layouts.at("LAYOUT4-8")->calcPos();
    layouts.at("LAYOUT4-9")->calcPos();

    //------------------------------------------------------------
    layouts.add("LAYOUT4-11",new gui::Layout(550,350,"horiz_grid",70));
    layouts.add("LAYOUT4-12",new gui::Layout(550,380,"horiz_grid",70));
    layouts.add("LAYOUT4-13",new gui::Layout(510,420,"vert_size",100));

    ui.add("LAY4-11-BTN1", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-11-CHECK1", new gui::ToggleSwitch(0,0,50,20,font));

    ui.add("LAY4-12-BTN2", new gui::Button(0,0,50,20,font,"",12));
    ui.add("LAY4-12-CHECK2", new gui::ToggleSwitch(0,0,50,20,font));

    layouts.at("LAYOUT4-11")->addElement(ui.at("LAY4-11-BTN1"));
    layouts.at("LAYOUT4-11")->addElement(ui.at("LAY4-11-CHECK1"));

    layouts.at("LAYOUT4-12")->addElement(ui.at("LAY4-12-BTN2"));
    layouts.at("LAYOUT4-12")->addElement(ui.at("LAY4-12-CHECK2"));

    layouts.at("LAYOUT4-13")->addElement(layouts.at("LAYOUT4-11"));
    layouts.at("LAYOUT4-13")->addElement(layouts.at("LAYOUT4-12"));

    
    layouts.at("LAYOUT4-11")->calcPos();
    layouts.at("LAYOUT4-12")->calcPos();
    layouts.at("LAYOUT4-13")->calcPos();

    ui.add("Testscalebtn", new gui::CheckBox(640,420,100.f,font));
    ui.add("Testscalebtn2", new gui::CheckBox(510,550,100.f,font));

    //--------------------------------------------------------------------------------
    // layouts.add("LAYOUT4-21",new gui::Layout(550,450,"vert_grid",40));
    // ui.add("LAY4-BTN1", new gui::Button(0,0,100,20,font,"",12));
    // ui.add("LAY4-BTN2", new gui::Button(0,0,100,20,font,"",12));
    // ui.add("LAY4-BTN3", new gui::Button(0,0,100,20,font,"",12));

    // layouts.at("LAYOUT4-21")->addElement(ui.at("LAY4-BTN1"));
    // layouts.at("LAYOUT4-21")->addElement(ui.at("LAY4-BTN2"));
    // layouts.at("LAYOUT4-21")->addElement(ui.at("LAY4-BTN3"));

    // layouts.at("LAYOUT4-21")->calcPos();
    // //checkbox without layout
    // ui.add("SEC4CHECK", new gui::CheckBox(680,450,100,font));


    //Create event variable
    sf::Event event;

    //-------------------------Main loop----------------------------

    while(window.isOpen()){
        //reset delta time
        dt = dtClock.restart().asSeconds();
        //update mouse pos
        mousePosWindow = sf::Mouse::getPosition(window);
        
       // check all the window's events that were triggered since the last iteration of the loop
        while (window.pollEvent(event))
        {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
                
                window.close();
        }

        //Updateing
        ui.update(mousePosWindow, dt);

        //Rendering
        window.clear();

        window.draw(section1Bg);
        window.draw(section2Bg);
        window.draw(section2BottomHalve);
        window.draw(section3Bg);
        window.draw(section4Bg);



        ui.render(window);
        window.display();
        
    }

    ui.clear();
    return 0;
}


