#include "game.hpp"


//          Private functions
void Game::initVariables()
{
    this->window = nullptr;

    //Game logic
    this->endGame = false;
    this->points = 0;
    this->health = 30;
    this->mouseHeld = false;
}

void Game::initWindow()
{
    this->videoMode.height = 750;
    this->videoMode.width = 1000; 
    this->window = new sf::RenderWindow(this->videoMode, " sfml game 1", sf::Style::Titlebar | sf::Style::Close);
    this->window->setFramerateLimit(60);
    
}

void Game::initFonts()
{
    if(!this->font.loadFromFile("../../src/fonts/Roboto-BlackItalic.ttf"))
    {
        std::cout << "Error::Game::INITFONTS Failed to load font!" << "\n";
    }
}




void Game::initGui()
{
    //Load Button Textures
    if(!this->idleTex.loadFromFile("../../src/buttonidle.png")){
        std::cout << "ERROR::INITGUI::Could not load idle button texture!" << "\n";
    }
    if(!this->hoverTex.loadFromFile("../../src/buttonHover.png")){
        std::cout << "ERROR::INITGUI::Could not load hover button texture!" << "\n";
    }
    if(!this->activeTex.loadFromFile("../../src/buttonActive.png")){
        std::cout << "ERROR::INITGUI::Could not load active button texture!" << "\n";
    }
    
    //Init layouts
    this->layouts.add("LAYOUT1", new gui::Layout(100.f,100.f,"vert_pad",20.f));
    //Init Buttons
    int char_size = 26;
    std::string text = "Buttons1";
    this->ui.add("BUTTON1",
      new gui::Button(250.f,100.f,150.f,40.f,
        this->font,text, char_size,
        sf::Color(70,70,70,230), sf::Color(250,250,250,255), sf::Color(20,20,20,50),
        sf::Color(70,70,70,230), sf::Color(150,150,150,255), sf::Color(20,20,20,50)
        )
       
    );

    gui::Button templateButton(250.f,100.f,150.f,40.f,
        this->font,text, char_size,
        sf::Color(170,70,70,230), sf::Color(250,150,150,255), sf::Color(120,20,20,50),
        sf::Color(70,70,170,230), sf::Color(150,150,250,255), sf::Color(20,20,120,50)
    );

    this->ui.add("BUTTON2" , new gui::Button(10,100,150,50,"Button2",&templateButton));
    this->ui.add("BUTTON3" ,new gui::Button(10,250,150,50,"Button3",&templateButton));
    
    this->layouts.at("LAYOUT1")->addElement(this->ui.at("BUTTON1"));
    this->layouts.at("LAYOUT1")->addElement(this->ui.at("BUTTON2"));
    this->layouts.at("LAYOUT1")->addElement(this->ui.at("BUTTON3"));
    this->layouts.at("LAYOUT1")->calcPos();
}



//          Constructors / Destructors
Game::Game()
{
    this->initVariables();
    this->initWindow();
    this->initFonts();
    this->initGui();
    
   
}

Game::~Game()
{
    delete this->window;
   
    this->ui.clear();  
    this->layouts.clear(); 

}

//      running
const bool Game::running() const
{
    return this->window->isOpen();
}


//      end game
const bool Game::getEndGame() const
{
    return this->endGame;
}

// functions

void Game::pollEvents()
{
   while(window->pollEvent(this->ev)){
            switch(this->ev.type){
                case sf::Event::Closed:
                this->window->close();
                break;
                case sf::Event::KeyPressed:
                    if(this->ev.key.code == sf::Keyboard::Escape)
                        this->window->close();
                        break;
            }
        }  
}

void Game::updateMousePositions()
{
    /*
        return void
        updates mouse positions relative to window( Vector2i)
    */
   this->mousePosWindow = sf::Mouse::getPosition(*this->window);
   this->mousePosView = this->window->mapPixelToCoords(this->mousePosWindow);
}


void Game::updateGui()
{

    this->ui.update(this->mousePosWindow, this->dt);
    this->layouts.update(this->mousePosWindow, this->dt);
        
       
}





void Game::updateDT()
{
    /*Update the dt variable with the time it takes to complete one frame*/
    this->dt = this->dtClock.restart().asSeconds();

}

void Game::update()
{
        this->updateDT();
        this->pollEvents();

        if(this->endGame == false){}
            this->updateMousePositions();
            this->updateGui();

}







void Game::renderGui(sf::RenderTarget &target)
{
    
    this->ui.render(target);
  
}

void Game::render()
{
    /*
        Renders game objects
        -clear
        -render objects
        -display frame window
    */

    this->window->clear();
   

    this->renderGui(*this->window);

    this->window->display();
}
