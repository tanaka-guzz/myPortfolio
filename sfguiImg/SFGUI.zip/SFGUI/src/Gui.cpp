#include"Gui.h"

//--=============================== GUI Base Class ==================================================
gui::UIElement::UIElement()
{
    this->keyTime = 0;
    this->keyTimeMax = 3;
}

gui::UIElement::~UIElement()
{
}

const bool gui::UIElement::getKeyTime()
{
    if(this->keyTime >= this->keyTimeMax){
        this->keyTime = 0.f;
        return true;
    }
    return false;
}

void gui::UIElement::updateKeyTime(const float& dt)
{
    if(this->keyTime < keyTimeMax){
        this->keyTime += 10.f * dt;
    }
}


const float gui::p2pX(const float percent, const sf::VideoMode& vm)
{
    /*
     *Converts a percent to a pixel value relative to the games resolution in the x axis.
     *
     *@param    float percent       The percentage value
     *@param    sf::VideoMode& vm   The current videoMode of the window (resolution).
     *
     * 
     *@return   float               The pixel value 
     */
    return std::floor( static_cast<float>( vm.width) * (percent / 100.f) );
}

const float gui::p2pY(const float percent, const sf::VideoMode& vm)
{
    /*
     *Converts a percent to a pixel value relative to the games resolution in the y axis.
     *
     *@param    float percent       The percentage value
     *@param    sf::VideoMode& vm   The current videoMode of the window (resolution).
     *
     *@return   float               The pixel value  
     */
    return std::floor( static_cast<float>( vm.height) * (percent / 100.f) );
}

void gui::move(const float x, const float y, gui::UIElement *element)
{
        element->setPosition(
            element->getPosition().x + x,
            element->getPosition().y + y
        );
}

const unsigned gui::calCharSize(const sf::VideoMode& vm,const unsigned modifiyer)
{
    /*
     *Calculate the character size for the text using the current resolution and a constant.
     *
     *@param    sf::VideoMode& vm   The current videoMode of the window (resolution).
     *@param    unsigned modifiyer  used to modifiy the character size
     * 
     *@return   unsigned               The Character size value 
     */
    return static_cast<unsigned>((vm.width + vm.height)/modifiyer);
}

void gui::align(std::string axis, sf::IntRect base, gui::UIElement *element)
{
    /*
     *Takes a videomode screen and a ui element and uses the axis paramater to align     
     *the element within the screen.
     *
     *@param    std::string axis    Used to choose the type of alignment to the screen
     *@param    sf::Rect base       The current rect of the window or object to be aligned to
     *@param    gui::UIElement* element    The element that is going to be aligned to the screen    
     * 
     *@return   void 
     */
    
    if(axis == "center"){
        element->setPosition(
            base.left + base.width/2  - element->getSize().x/2,
            base.top + base.height/2 - element->getSize().y/2);
        //base.height/2 - element->getSize().y/2 
    }
    else if(axis == "center_x"){
        element->setPosition(base.left + base.width/2  - element->getSize().x/2, element->getPosition().y);
    }
    else if(axis == "center_y"){
        element->setPosition(element->getPosition().x, base.top + base.height/2 - element->getSize().y/2);
    }
    else if(axis == "left"){
        element->setPosition(base.left , element->getPosition().y);
    }
    else if(axis == "right"){
        element->setPosition(base.left + base.width - element->getSize().x, element->getPosition().y);
    }
    else if(axis == "top"){
        element->setPosition(element->getPosition().x, base.top);
    }
    else if(axis == "bottom"){
        element->setPosition(element->getPosition().x, base.top + base.height - element->getSize().y);
    }
    else{
        std::cout << "ERROR::GUI.CPP::ALIGHN()::invalid alignment axis specified" << "\n";
    }
}

void gui::align(std::string axis, sf::VideoMode &vm, gui::UIElement *element)
{
    /*
     *Takes a videomode screen and a ui element and uses the axis paramater to align     
     *the element within the screen.
     *
     *@param    std::string axis    Used to choose the type of alignment to the screen
     *@param    sf::VideoMode& vm   The current videoMode of the window (screen resolution)
     *@param    gui::UIElement* element    The element that is going to be aligned to the screen    
     * 
     *@return   void 
     */
    if(axis == "center"){
        element->setPosition(vm.width/2 - element->getSize().x/2, vm.height/2 - element->getSize().y/2);
    }
    else if(axis == "center_x"){
        element->setPosition(vm.width/2 - element->getSize().x/2, element->getPosition().y);
    }
    else if(axis == "center_y"){
        element->setPosition(element->getPosition().x, vm.height/2 - element->getSize().y/2);
    }
    else if(axis == "left"){
        element->setPosition(0 , element->getPosition().y);
    }
    else if(axis == "right"){
        element->setPosition(vm.width - element->getSize().x, element->getPosition().y);
    }
    else if(axis == "top"){
        element->setPosition(element->getPosition().x, 0);
    }
    else if(axis == "bottom"){
        element->setPosition(element->getPosition().x, vm.height - element->getSize().y);
    }
    else{
        std::cout << "ERROR::GUI.CPP::ALIGHN()::invalid alignment axis specified" << "\n";
    }
   
        
}

//--==================================Text===========================================
gui::Text::Text(float x,float y,sf::Font& font,int char_size, std::string in_string, sf::Color text_color)
    :font(font)
{
    this->type = ui_types::TEXT;
    this->string = in_string;
    this->textColor = text_color;
    this->charSize = char_size;

    this->text.setFont(this->font);
    sf::FloatRect textRect = this->text.getLocalBounds();
    this->text.setOrigin(
        textRect.left + textRect.width/2.0f,
        textRect.top  + textRect.height/2.0f
    );
    this->text.setPosition(x,y);
    this->text.setCharacterSize(char_size);
    this->text.setFillColor(text_color);
    this->text.setString(string);

    this->backGround.setFillColor(sf::Color::Black);
    this->backGround.setPosition(x,y);
    this->backGround.setSize(sf::Vector2f(100,30));
}

gui::Text::~Text()
{
}



//Accessors
const int gui::Text::getValue() const
{
    return 0;
}

const sf::Vector2f &gui::Text::getPosition()
{
    return this->text.getPosition();
}

const sf::Vector2f gui::Text::getSize()
{
    return sf::Vector2f();
}

//Modifiyers
void gui::Text::setPosition(const float x, const float y)
{
    this->text.setPosition(x,y);
}

void gui::Text::setSize(const float width, const float height)
{
}



bool gui::Text::update(const sf::Vector2i mouse_pos, const float &dt)
{
    return false;
}

void gui::Text::render(sf::RenderTarget &target)
{
    //target.draw(this->backGround);
    target.draw(this->text);

}



//--==================================Button===========================================
//Constructor / Destructor
gui::Button::Button(float x, float y, float width, float height,
        sf::Font& font, std::string text,unsigned character_size,
        sf::Color text_idle_color, sf::Color text_hover_color, sf::Color text_active_color,
        sf::Color idle_color,sf::Color hover_color,sf::Color active_color,
        sf::Color outline_idle_color,sf::Color outline_hover_color,sf::Color outline_active_color, 
        short unsigned id)
            :font(font)
{
    this->type = ui_types::BUTTON;
    this->buttonState = BTN_IDLE; 
    this->id = id; 
    this->characterSize = character_size; 
    this->shape.setPosition(sf::Vector2f(x,y));
    this->shape.setSize(sf::Vector2f(width,height));
    this->shape.setFillColor(idle_color);
    this->shape.setOutlineThickness(1.f);
    this->shape.setOutlineColor(outline_idle_color);


    this->text.setFont(this->font);
    this->text.setString(text);
    this->text.setFillColor(text_idle_color);
    this->text.setCharacterSize(character_size);
    
    //fixing the text for centering
    // float maxHeight = 0;
    // float currentHeight = 0;
    // for (size_t characterIndex = 0; characterIndex < text.size(); ++characterIndex){
    //     currentHeight = this->font.getGlyph(text[characterIndex], 12, false).bounds.height;
    //     if (currentHeight > maxHeight){
    //             maxHeight = currentHeight;
    //     }
    // }

    sf::FloatRect textRect = this->text.getLocalBounds();
    this->text.setOrigin(
        textRect.left + textRect.width/2.0f,
        textRect.top  + textRect.height/2.0f
    );
//---------------------------------

    this->text.setPosition(
        this->shape.getPosition().x + (this->shape.getGlobalBounds().width/2.f) ,
        this->shape.getPosition().y + (this->shape.getGlobalBounds().height/ 2.f)

    );

    this->textIdleColor = text_idle_color;
    this->textHoverColor = text_hover_color;
    this->textActiveColor = text_active_color;

    this->idleColor = idle_color;
    this->hoverColor = hover_color;
    this->activeColor = active_color;

    this->outlineIdleColor = outline_idle_color;
    this->outlineHoverColor = outline_hover_color;
    this->outlineActiveColor = outline_active_color;

}

gui::Button::Button(float x, float y, float width, float height, std::string text,Button* buttonStyle, short unsigned id)
    :font(buttonStyle->getFont())
{
    this->type = ui_types::BUTTON;
    this->characterSize = buttonStyle->getCharSize();
    this->idleColor = buttonStyle->getColor(1);
    this->hoverColor = buttonStyle->getColor(2);
    this->activeColor = buttonStyle->getColor(3);

    this->textIdleColor = buttonStyle->getColor(4);
    this->textHoverColor = buttonStyle->getColor(5);
    this->textActiveColor = buttonStyle->getColor(6);

    this->outlineIdleColor = buttonStyle->getColor(7);
    this->outlineHoverColor = buttonStyle->getColor(8);
    this->outlineActiveColor = buttonStyle->getColor(9);

    this->buttonState = BTN_IDLE; 
    this->id = id;  
    this->shape.setPosition(sf::Vector2f(x,y));
    this->shape.setSize(sf::Vector2f(width,height));
    this->shape.setFillColor(this->idleColor);
    this->shape.setOutlineThickness(1.f);
    this->shape.setOutlineColor(this->outlineIdleColor);


    this->text.setFont(buttonStyle->getFont());
    this->text.setString(text);
    this->text.setFillColor(this->textIdleColor);
    this->text.setCharacterSize(this->characterSize);
    sf::FloatRect textRect = this->text.getLocalBounds();
    this->text.setOrigin(
        textRect.left + textRect.width/2.0f,
        textRect.top  + textRect.height/2.0f
    );
    this->text.setPosition(
        this->shape.getPosition().x + (this->shape.getGlobalBounds().width/2.f) ,
        this->shape.getPosition().y + (this->shape.getGlobalBounds().height/ 2.f)

    );
    
}

gui::Button::~Button()
{
}


//Accessors

const bool gui::Button::isPressed() const
{
    if(this->buttonState == BTN_ACTIVE){
        return true;
    }
    return false;
}

const std::string gui::Button::getText() const
{
    return this->text.getString();
}

const short unsigned &gui::Button::getId() const
{
    return this->id;
}

const sf::Vector2f gui::Button::getSize()
{
    return this->shape.getSize();
}

const sf::Vector2f &gui::Button::getPosition()
{
    return this->shape.getPosition();
}

const int gui::Button::getValue() const
{
    return 0;
}

const sf::Color &gui::Button::getColor(int index)
{
    switch(index){
        case 1:
            return this->idleColor;
        break;
        case 2:
            return this->hoverColor;
        break;
        case 3:
            return this->activeColor;
        break;
        case 4:
            return this->textIdleColor;
        break;
        case 5:
            return this->textHoverColor;
        break;
        case 6:
            return this->textActiveColor;
        break;
        case 7:
            return this->outlineIdleColor;
        break;
        case 8:
            return this->outlineHoverColor;
        break;
        case 9:
            return this->outlineActiveColor;
        break;
        default:
            return this->idleColor;
    }
}

sf::Font &gui::Button::getFont()
{
    return this->font;
}

const unsigned &gui::Button::getCharSize()
{
    return this->characterSize;
}

//Modifiers

void gui::Button::setText(const std::string& text)
{
    this->text.setString(text);
}

void gui::Button::setId(const short unsigned id)
{
    this->id = id;
}

void gui::Button::setPosition(const float x, const float y)
{
    this->shape.setPosition(x, y);
    this->text.setPosition(
        this->shape.getPosition().x + (this->shape.getGlobalBounds().width/2.f),
        this->shape.getPosition().y + (this->shape.getGlobalBounds().height/ 2.f)

    );
}

void gui::Button::setSize(const float width, const float height)
{
    this->shape.setSize(sf::Vector2f(width,height));
}

void gui::Button::changeBtnColor(sf::Color idle, sf::Color hover, sf::Color active)
{
    this->idleColor = idle;
    this->hoverColor = hover;
    this->activeColor = active;
}

// Functions
bool gui::Button::update(const sf::Vector2i mouse_pos,  const float& dt)
{
    this->updateKeyTime(dt);
    /*Update the booleans for hover and pressed*/

    //Idle
    this->buttonState = BTN_IDLE;

    //Hover
    if(this->shape.getGlobalBounds().contains(static_cast<sf::Vector2f>(mouse_pos))){
        this->buttonState = BTN_HOVER;

        //Pressed
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left) && this->getKeyTime()){
            this->buttonState = BTN_ACTIVE;
        }
    }

    switch(this->buttonState){
        case BTN_IDLE:
            this->shape.setFillColor(this->idleColor);
            this->text.setFillColor(this->textIdleColor);
            this->shape.setOutlineColor(this->outlineIdleColor);
        break;
        case BTN_HOVER:
            this->shape.setFillColor(this->hoverColor);
            this->text.setFillColor(this->textHoverColor);
            this->shape.setOutlineColor(this->outlineHoverColor);
            return true;
        break;
        case BTN_ACTIVE:
            this->shape.setFillColor(this->activeColor);
            this->text.setFillColor(this->textActiveColor);
            this->shape.setOutlineColor(this->outlineActiveColor);
            return true;
        break;
        default:
            this->shape.setFillColor(sf::Color::Red);
            this->text.setFillColor(sf::Color::Black);
            this->shape.setOutlineColor(sf::Color::Green);
        break;

    }
    return false;
}

void gui::Button::render(sf::RenderTarget& target)
{
    target.draw(this->shape);
    target.draw(this->text);
}


//--======================================= Image Button ==================================================

gui::IButton::IButton(const float x, const float y, sf::Texture &idle_tex, sf::Texture &hover_tex, sf::Texture &active_tex )
    :idleTex(idle_tex), hoverTex(hover_tex), activeTex(active_tex)
{
    this->type = ui_types::IBUTTON;
    this->sprite.setPosition(x,y);
    this->sprite.setTexture(idleTex);
}

gui::IButton::~IButton()
{
}

const bool gui::IButton::isPressed() const
{
    if(this->buttonState == BTN_ACTIVE){
        return true;
    }
    return false;
}

const int gui::IButton::getValue() const
{
    return 0;
}

const sf::Vector2f &gui::IButton::getPosition()
{
    return this->sprite.getPosition();
}

const sf::Vector2f gui::IButton::getSize()
{
    return this->sprite.getGlobalBounds().getSize();
    
}

void gui::IButton::setPosition(const float x, const float y)
{
    this->sprite.setPosition(x,y);
}

void gui::IButton::setSize(const float width, const float height)
{
    float xScale = width / this->sprite.getGlobalBounds().left;
    float yScale = height / this->sprite.getGlobalBounds().top;
    this->sprite.setScale(xScale,yScale);
}

bool gui::IButton::update(sf::Vector2i mouse_pos, const float &dt)
{
    this->updateKeyTime(dt);
    
    this->buttonState = BTN_IDLE;

    if(this->sprite.getGlobalBounds().contains(mouse_pos.x, mouse_pos.y)){
        this->buttonState = BTN_HOVER;

        if(sf::Mouse::isButtonPressed(sf::Mouse::Left) &&this->getKeyTime()){
            this->buttonState = BTN_ACTIVE;
        }
    }

    switch(this->buttonState){
        case BTN_IDLE:
            this->sprite.setTexture(this->idleTex);
        break;
        case BTN_HOVER:
            this->sprite.setTexture(this->hoverTex);
        break;
        case BTN_ACTIVE:
            this->sprite.setTexture(this->activeTex);
        break;
        default:
            this->sprite.setColor(sf::Color::Red);
        break;

    }

    return false;

}

void gui::IButton::render(sf::RenderTarget &target)
{
    target.draw(this->sprite);
}

//--======================================= Check Box ==================================================

gui::CheckBox::CheckBox(float x, float y, float size,sf::Font& font, sf::Color container, sf::Color check_color, bool value)
{
    this->type = ui_types::CHECKBOX;
    this->container = new gui::Button(
        x,y,
        size, size,
        font,"",0,
        sf::Color(100,100,100,200), sf::Color(100,100,100,255),sf::Color(100,200,200,150),
        sf::Color(200,200,200,200), sf::Color(200,200,200,255), sf::Color(200,200,200,150),
        sf::Color(255,255,255,255), sf::Color(150,150,150,255), sf::Color(255,255,255,50)
    );

    this->checkBox.setSize(sf::Vector2f(size * 0.8, size * 0.8));
    this->checkBox.setPosition(
        this->container->getPosition().x + this->container->getSize().x / 2.f - this->checkBox.getSize().x / 2.f,
        this->container->getPosition().y + this->container->getSize().y / 2.f - this->checkBox.getSize().y / 2.f
    );

    this->checkBox.setFillColor(check_color);
}

gui::CheckBox::~CheckBox()
{
    delete this->container;
}

const int gui::CheckBox::getValue() const
{
    return static_cast<int>(this->value);
}

const sf::Vector2f &gui::CheckBox::getPosition()
{
    return this->container->getPosition();
    
}

const sf::Vector2f gui::CheckBox::getSize()
{
    return this->container->getSize();
}

void gui::CheckBox::setPosition(const float x, const float y)
{
    this->container->setPosition(x,y);
    this->checkBox.setPosition(
        this->container->getPosition().x + this->container->getSize().x / 2.f - this->checkBox.getSize().x / 2.f,
        this->container->getPosition().y + this->container->getSize().y / 2.f - this->checkBox.getSize().y / 2.f
    );

}

void gui::CheckBox::setSize(const float width, const float height)
{
    this->container->setSize(width,height);
    this->checkBox.setSize(sf::Vector2f(this->container->getSize().x * 0.8, this->container->getSize().y * 0.8));
    this->checkBox.setPosition(
        this->container->getPosition().x + this->container->getSize().x / 2.f - this->checkBox.getSize().x / 2.f,
        this->container->getPosition().y + this->container->getSize().y / 2.f - this->checkBox.getSize().y / 2.f
    );
}

bool gui::CheckBox::update(sf::Vector2i mouse_pos, const float &dt)
{
    this->updateKeyTime(dt);
    this->container->update(mouse_pos, dt);
    if(this->container->isPressed() && getKeyTime()){
        if(this->value){
            this->value = false;
        }
        else{
            this->value = true;
        }
        
    }
    return false;
}

void gui::CheckBox::render(sf::RenderTarget &target)
{
    this->container->render(target);
    if(this->value){
        target.draw(this->checkBox);
    }
    
}

//--======================================= Toggle Switch ==================================================

gui::ToggleSwitch::ToggleSwitch(const float x, const float y, const float width, const float height, sf::Font& font)
{
    this->type = ui_types::TOGGLE;
    this->value = false;
    this->container.setPosition(x,y);
    this->container.setSize(sf::Vector2f(width,height));
    this->container.setFillColor(sf::Color(150,150,150,255));
    this->pad = 3.f;
    this->button = new gui::Button(
        this->container.getPosition().x + pad,this->container.getPosition().y + pad,
        this->container.getSize().x * 0.4, this->container.getSize().y * 0.8 ,
        font,"",0,
        sf::Color(100,100,100,200), sf::Color(100,100,100,255),sf::Color(100,200,200,150),
        sf::Color(200,200,200,200), sf::Color(200,200,200,255), sf::Color(200,200,200,150),
        sf::Color::Transparent, sf::Color::Transparent, sf::Color::Transparent);
}

gui::ToggleSwitch::~ToggleSwitch()
{
    delete this->button;
}

//Accessors
const int gui::ToggleSwitch::getValue() const
{
    return static_cast<float>(this->value);
}

const sf::Vector2f &gui::ToggleSwitch::getPosition()
{
    return this->container.getPosition();
}

const sf::Vector2f gui::ToggleSwitch::getSize()
{
    return this->container.getSize();
}

void gui::ToggleSwitch::setPosition(const float x, const float y)
{
    this->container.setPosition(x,y);
    if(this->value == false){
            this->button->setPosition(this->container.getPosition().x + this->container.getSize().x - this->button->getSize().x - this->pad,
                this->container.getPosition().y + this->pad);
        }
        else{
            this->button->setPosition(this->container.getPosition().x + this->pad,
                this->container.getPosition().y + this->pad);
        }
}

void gui::ToggleSwitch::setSize(const float width, const float height)
{
    this->container.setSize(sf::Vector2f(width,height));
    this->button->setPosition(this->container.getPosition().x + this->pad, this->container.getPosition().y + this->pad);
    this->button->setSize(this->container.getSize().x * 0.4, this->container.getSize().y * 0.8);
}

//Functions


bool gui::ToggleSwitch::update(sf::Vector2i mouse_pos, const float &dt)
{
    this->button->update(mouse_pos, dt);

    if(this->button->isPressed()){
        if(this->value == false){
            this->value = true;
            this->button->setPosition(this->container.getPosition().x + this->container.getSize().x - this->button->getSize().x - this->pad,
                this->container.getPosition().y + this->pad);
        }
        else{
            this->value = false;
            this->button->setPosition(this->container.getPosition().x + this->pad,
                this->container.getPosition().y + this->pad);
        }
       
    }
    return false;
}

void gui::ToggleSwitch::render(sf::RenderTarget &target)
{
    target.draw(this->container);
    this->button->render(target);
}


//--======================================= Drop Down List ==================================================

//Constructor / destructor
gui::DropDownList::DropDownList(float x, float y,float width, float height,sf::Font& font, std::string List[],unsigned no_of_elements,unsigned default_index)
    :font(font), showList(false), noOfElements(no_of_elements)
{
    this->type = ui_types::DROPDOWN;
    this->height = height;
    this->activeElement = new gui::Button(x, y ,width,height,
            this->font,List[default_index], 12,
            sf::Color(255,255,255,230), sf::Color(250,250,250,255), sf::Color(255,255,255,50),
            sf::Color(70,70,70,200), sf::Color(150,150,150,200), sf::Color(20,20,20,200),
            sf::Color(255,255,255,255), sf::Color(150,150,150,255), sf::Color(255,255,255,50)
            
        );

    for(unsigned i=0; i < no_of_elements; i++){

        this->list.push_back(
        new gui::Button(x, y + ((i+1) * height) ,width,height,
            this->font,List[i], 12,
            sf::Color(255,255,255,230), sf::Color(250,250,250,255), sf::Color(255,255,255,50),
            sf::Color(70,70,70,200), sf::Color(150,150,150,200), sf::Color(20,20,20,200),
            sf::Color(255,255,255,0), sf::Color(150,150,150,0), sf::Color(255,255,255,0),
            i
        )
    );

    }
    

}

gui::DropDownList::DropDownList(float x, float y, float width, float height, std::string List[], unsigned no_of_elements, gui::Button* template_btn, unsigned default_index)
    :font(template_btn->getFont()), showList(false)
{
    this->type = ui_types::DROPDOWN;
    this->height = height;
    this->activeElement = new gui::Button(x, y ,width,height,List[default_index],template_btn);

    for(unsigned i=0; i < no_of_elements; i++){

        this->list.push_back(
            new gui::Button(x, y + ((i+1) * height) ,width,height,List[i], template_btn,i)
        );

    }
    

}

gui::DropDownList::~DropDownList()
{
    delete this->activeElement;
    for(size_t i = 0; i < this->list.size(); i++){
        delete this->list[i];
    } 
}






//Accesors

const short unsigned &gui::DropDownList::getActiveElementId() const
{
    return this->activeElement->getId();
}

const int gui::DropDownList::getValue() const
{
    return 0;
}

const sf::Vector2f &gui::DropDownList::getPosition()
{
    return this->activeElement->getPosition();
}

const sf::Vector2f gui::DropDownList::getSize()
{
    return this->activeElement->getSize();
}

const int gui::DropDownList::getType()
{
    return this->type;
}

//Modifiyers

void gui::DropDownList::setPosition(const float x, const float y)
{
    this->activeElement->setPosition(x,y);

    for(unsigned i=0; i < this->list.size(); i++){

        this->list[i]->setPosition(x , y + ((i+1) * this->height));
    }
    

}

void gui::DropDownList::setSize(const float width, const float height)
{
    this->activeElement->setSize(width, height);
    for(size_t i = 0; i < this->list.size(); i++){
        this->list[i]->setSize(width,height);
    } 
}

//Functions


bool gui::DropDownList::update(const sf::Vector2i mouse_pos,  const float& dt)
{
    bool active = false;
    this->updateKeyTime(dt);

    this->activeElement->update(mouse_pos, dt);

    //Show and hide the list
    if(this->activeElement->isPressed() && this->getKeyTime()){
        if(this->showList){
            this->showList = false;
        }else{
            this->showList = true;
        }
    }

    if(this->showList){
        for(auto &i: this->list){
            active = i->update(mouse_pos, dt);
            if(active == true){
                //std::cout << "dropdown showlist"<< "\n";
                return true;}
            if(i->isPressed() && this->getKeyTime()){
                
                this->showList = false;
                this->activeElement->setText(i->getText());
                this->activeElement->setId(i->getId());
            }
        }
    }
    //std::cout << "..." << "\n";
    return active;
    
}

void gui::DropDownList::render(sf::RenderTarget &target)
{
    this->activeElement->render(target);

    if(this->showList){
        for(auto &i: this->list){
            i->render(target);
        }
    }
}

//--===================================== Radio List =======================================================

gui::RadioList::RadioList(float x, float y, float width, float height, sf::Font &font, std::string List[], unsigned no_of_elements, unsigned default_index)
    :gui::UIElement(), font(font)
{
    this->type = ui_types::RADIOLIST;
    this->btnHeight = height;
    this->btnWidth = width;

    this->spacing = 5.f;
    
    for(int i = 0; i < no_of_elements; i++ ){
        this->list.push_back(new gui::Button(x +  ((i)*width) + (this->spacing*i), y ,width,height,
            this->font,List[i], 12,
            sf::Color(255,255,255,230), sf::Color(250,250,250,255), sf::Color(255,255,255,50),
            sf::Color(70,70,70,200), sf::Color(150,150,150,200), sf::Color(20,20,20,200),
            sf::Color(255,255,255,255), sf::Color(150,150,150,255), sf::Color(255,255,255,50),
            i
            
            )
        );
    }

}

gui::RadioList::RadioList(float x, float y, float width, float height, std::string List[], unsigned no_of_elements, gui::Button *template_btn, unsigned default_index)
    :gui::UIElement(), font(template_btn->getFont())
{
    this->btnHeight = height;
    this->btnWidth = width;

    this->spacing = 5.f;
    
    for(int i = 0; i < no_of_elements; i++ ){
        this->list.push_back(new gui::Button(x +  ((i+1)*width) + (this->spacing*i+1), y ,width,height,List[i],template_btn));
        
    }

}

gui::RadioList::~RadioList()
{
}

const int &gui::RadioList::getActiveId() const
{
    return this->activeId;
}

const int gui::RadioList::getValue() const
{
    return 0;
}

const sf::Vector2f &gui::RadioList::getPosition()
{
    return this->list[0]->getPosition();
}

const sf::Vector2f gui::RadioList::getSize()
{
    return sf::Vector2f((this->btnWidth + this->spacing) * this->list.size(),this->btnHeight);
}

void gui::RadioList::setPosition(const float x, const float y)
{
    for(int i = 0; i < this->list.size(); i++){
        this->list[i]->setPosition(x +  (i*this->btnWidth) + (this->spacing*i), y );
    }
}

void gui::RadioList::setSize(const float width, const float height)
{
    this->btnWidth = width;
    this->btnHeight = height;
    float x = this->list[0]->getPosition().x;
    float y = this->list[0]->getPosition().y;
    for(int i = 0; i < this->list.size(); i++){
        this->list[i]->setSize(this->btnWidth,this->btnHeight);
    }

    for(int i = 0; i < this->list.size(); i++){
        this->list[i]->setPosition(x +  (i*this->btnWidth) + (this->spacing*i), y );
    }
}

bool gui::RadioList::update(sf::Vector2i mouse_pos, const float& dt)
{
    updateKeyTime(dt);
    for(auto &i : this->list){
        i->update(mouse_pos, dt);
    }

    for(auto &i : this->list){
        if(i->isPressed() && this->getKeyTime()){
            for(auto &i : this->list){
                i->changeBtnColor(sf::Color(70,70,70,200),sf::Color(150,150,150,200),sf::Color(20,20,20,200));
            }
            this->activeId = i->getId();
            i->changeBtnColor(sf::Color(100,100,250,200),sf::Color(100,100,250,250),sf::Color(100,100,250,150));
            
        }
    }
    return false;
}

void gui::RadioList::render(sf::RenderTarget &target)
{
    

    for(auto &i : this->list){
        i->render(target);
    }
}

//--===================================== Slider =======================================================




gui::Slider::Slider(float x, float y,float width, float height, sf::Color color, float min_value, float max_value, float start_value)
{
    this->type = ui_types::SLIDER;
    this->isHeld = false;

    this->minValue = min_value;
    this->maxValue = max_value;
    this->currValue = start_value;
    this->prevValue = currValue;

    this->sliderBar.setSize(sf::Vector2f(width , height));
    this->sliderBar.setPosition(sf::Vector2f(x,y));
    this->sliderBar.setFillColor(color);

   
    this->sliderButton.setSize(sf::Vector2f(width * 0.1f, height * 1.68f));

    this->sliderButton.setPosition(this->sliderBar.getPosition().x  + (this->currValue - this->minValue) / (this->maxValue - this->minValue) * (this->sliderBar.getSize().x - this->sliderButton.getSize().x)    , this->sliderBar.getPosition().y + this->sliderBar.getSize().y / 2.f - this->sliderButton.getSize().y / 2.f);
    this->sliderButton.setFillColor(color);
}

gui::Slider::~Slider()
{
}


//Accessors



const int gui::Slider::getValue() const
{
    return 0.0f;
}

void gui::Slider::setValue(int value)
{
    //Set the slider button to a position within the bar
    this->sliderButton.setPosition(  
        std::max
        ( 
            std::min
            (
                (value - this->sliderButton.getSize().x / 2.f), 
                this->sliderBar.getPosition().x + this->sliderBar.getSize().x - this->sliderButton.getSize().x
            ),
            this->sliderBar.getPosition().x
        ),
        this->sliderButton.getPosition().y);
    //set current value depending on position of butotn
    this->currValue = ((this->sliderButton.getPosition().x - this->sliderBar.getPosition().x) * (maxValue - minValue)) / (this->sliderBar.getSize().x - this->sliderButton.getSize().x) + minValue;
    
   

}

bool gui::Slider::isPressed()
{
    if(this->buttonState == BTN_ACTIVE){
        return true;
    }
    return false;
}

const sf::Vector2f &gui::Slider::getPosition()
{
    return this->sliderBar.getPosition();
}

const sf::Vector2f gui::Slider::getSize()
{
    return this->sliderBar.getSize();
}

void gui::Slider::setPosition(const float x, const float y)
{
    this->sliderBar.setPosition(x,y);
    this->sliderButton.setPosition(this->sliderBar.getPosition().x  + (this->currValue - this->minValue) / (this->maxValue - this->minValue) * (this->sliderBar.getSize().x - this->sliderButton.getSize().x)    , this->sliderBar.getPosition().y + this->sliderBar.getSize().y / 2.f - this->sliderButton.getSize().y / 2.f);
}

void gui::Slider::setSize(const float width, const float height)
{
    this->sliderBar.setSize(sf::Vector2f(width,height));
    this->sliderButton.setSize(sf::Vector2f(width * 0.1f, height * 1.68f));
    this->sliderButton.setPosition(this->sliderBar.getPosition().x  + (this->currValue - this->minValue) / (this->maxValue - this->minValue) * (this->sliderBar.getSize().x - this->sliderButton.getSize().x)    , this->sliderBar.getPosition().y + this->sliderBar.getSize().y / 2.f - this->sliderButton.getSize().y / 2.f);

}

//Functions



bool gui::Slider::update(const sf::Vector2i mouse_pos,  const float& dt)
{
    this->buttonState = BTN_IDLE;

    if(this->sliderButton.getGlobalBounds().contains(mouse_pos.x,mouse_pos.y )){
        this->buttonState = BTN_HOVER;
            if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
                this->buttonState = BTN_ACTIVE;
            }
    }
    if(this->isHeld){
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
            this->sliderButton.setFillColor(sf::Color::Yellow);// change color
            this->setValue(mouse_pos.x);
        }
        else{
            this->isHeld = false;
        }
    }
    else{

        switch(this->buttonState){
            case BTN_IDLE:
                this->sliderButton.setFillColor(sf::Color::White);
            break;

            case BTN_HOVER:
                this->sliderButton.setFillColor(sf::Color::Blue);// change color
            break;

            case BTN_ACTIVE:
            this->sliderButton.setFillColor(sf::Color::Yellow);// change color
            this->setValue(mouse_pos.x);
            this->isHeld = true;
                
                // Check for max and min value std::max
            break;

            default:
                this->sliderButton.setFillColor(sf::Color::Red);// change color
            break;
        }
    }
   return false;
    
}

void gui::Slider::render(sf::RenderTarget &target)
{
    target.draw(this->sliderBar);
    target.draw(this->sliderButton);
}

//--===================================== Pannel =======================================================


gui::Pannel::Pannel(const float x, const float y, const float width, const float height, sf::Font& font, std::string title, const int char_size, sf::RenderTexture& pannel_render)
    :containerRender(pannel_render)
{
    this->type = ui_types::PANNEL;
    this->prevLeftMose = false;
    this->container.setPosition(sf::Vector2f(x,y));
    this->container.setSize(sf::Vector2f(width,height));
    this->containerRender.create(width, height);
    this->container.setFillColor(sf::Color::White);
    this->container.setOutlineThickness(1.5f);
    this->container.setOutlineColor(sf::Color::Magenta);

    this->topBar.setPosition(
        this->container.getPosition().x,this->container.getPosition().y
    );
    this->topBar.setSize(
        sf::Vector2f(this->container.getSize().x, this->container.getSize().y * 0.08)
    );
    this->topBar.setFillColor(sf::Color::Blue);

    
}

gui::Pannel::~Pannel()
{
    
}

//Modifiyers

void gui::Pannel::toggleHidden()
{
    if(this->hidden == true){
            this->hidden = false;
    }
    else{
        this->hidden = true;
    }

    this->active = false;
}




const bool &gui::Pannel::getActive()
{
    return this->active;
}

const sf::Vector2f gui::Pannel::getPosition() const
{
    return this->container.getPosition();
}

//Functions
bool gui::Pannel::update(const sf::Vector2i mouse_pos,  const float& dt)
{
    
    this->active = false;

    if(this->isHeld){
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
          

            if(this->prevLeftMose){
            
                this->container.setPosition(static_cast<float>(mouse_pos.x - this->beforClick.x), static_cast<float>(mouse_pos.y - this->beforClick.y));
                this->topBar.setPosition(this->container.getPosition().x, this->container.getPosition().y);
            }
            else{
            
                this->beforClick.x  = mouse_pos.x -  this->container.getPosition().x ;
                this->beforClick.y = mouse_pos.y -  this->container.getPosition().y ;
                this->prevLeftMose = true;
            }
        }
        else{
            this->isHeld = false;
        }
    }
    else{
        //Inside of window
        if(!this->hidden){
            if(this->container.getGlobalBounds().contains(static_cast<sf::Vector2f>(mouse_pos))){    
                this->active = true;

                

                if(this->topBar.getGlobalBounds().contains(mouse_pos.x, mouse_pos.y))
                {
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
                        this->isHeld = true;

                        if(this->prevLeftMose){
                        
                            this->container.setPosition(static_cast<float>(mouse_pos.x - this->beforClick.x), static_cast<float>(mouse_pos.y - this->beforClick.y));
                            this->topBar.setPosition(this->container.getPosition().x, this->container.getPosition().y);
                        }
                        else{
                        
                            this->beforClick.x  = mouse_pos.x -  this->container.getPosition().x ;
                            this->beforClick.y = mouse_pos.y -  this->container.getPosition().y ;
                            this->prevLeftMose = true;
                        }
                    }
                    
                }
                else{
                    
                    this->prevLeftMose = false;
                }
                
            }
        }

    }
    return false;
}

void gui::Pannel::render(sf::RenderTarget &target)
{
    if(!this->hidden){
        // this->containerRender.clear(sf::Color(255,0,0,255));

        this->containerRender.display();
        this->outputTexture = containerRender.getTexture();
        this->containerRender.display();
        this->container.setTexture(&this->outputTexture);
        
        target.draw(this->container);
        target.draw(this->topBar);
    }
}



//--===================================== Texture Selector =======================================================




gui::TextureSelector::TextureSelector(float x, float y, float width, float height,float grid_size,
const sf::Texture *texture_sheet, sf::Font& font) :keyTimeMax(1.f),keyTime(keyTimeMax)
{
    this->gridSize = grid_size;
    this->active = false;
    this->hidden = false;
    this->hideBtnText = "TS";
    float offset = grid_size;

    this->bounds.setSize(sf::Vector2f(width,height));
    this->bounds.setPosition(x + offset,y);
    this->bounds.setFillColor(sf::Color(50,50,50,100));
    this->bounds.setOutlineThickness(2.f);
    this->bounds.setOutlineColor(sf::Color(255,255,255,200));

    this->sheet.setTexture(*texture_sheet);
    this->sheet.setPosition(x + offset,y);

    if(this->sheet.getGlobalBounds().width > this->bounds.getGlobalBounds().width){
        this->sheet.setTextureRect(sf::IntRect(0,0, static_cast<int>(this->bounds.getGlobalBounds().width), static_cast<int>(this->sheet.getGlobalBounds().height)));
    }
    if(this->sheet.getGlobalBounds().height > this->bounds.getGlobalBounds().height){
        this->sheet.setTextureRect(sf::IntRect(0,0,static_cast<int>(this->sheet.getGlobalBounds().width), static_cast<int>(this->bounds.getGlobalBounds().height)));
    }
    
    this->selector.setPosition(x + offset,y);
    this->selector.setSize(sf::Vector2f(grid_size,grid_size));
    this->selector.setFillColor(sf::Color::Transparent);
    this->selector.setOutlineThickness(1.f);
    this->selector.setOutlineColor(sf::Color::Red);

    this->textureRect.width = static_cast<int>(grid_size);
    this->textureRect.height = static_cast<int>(grid_size);
    
    this->hideBtn = new gui::Button(x,y,50,50,
    font,this->hideBtnText, 24,
    sf::Color(255,255,255,230), sf::Color(250,250,250,255), sf::Color(20,20,20,50),
    sf::Color(70,70,70,200), sf::Color(150,150,150,200), sf::Color(20,20,20,50));

}

gui::TextureSelector::~TextureSelector()
{
    delete this->hideBtn;
}

void gui::TextureSelector::toggleHidden()
{
    if(this->hidden == true){
            this->hidden = false;
    }
    else{
        this->hidden = true;
    }

    this->active = false;
}

//Accessors


const bool &gui::TextureSelector::getActive()
{
    return this->active;
}

const sf::IntRect &gui::TextureSelector::getTextureRect() const
{
    return this->textureRect;
}



//Functions

const bool gui::TextureSelector::getKeyTime()
{
    if(this->keyTime >= this->keyTimeMax){
        this->keyTime = 0.f;
        return true;
    }
    return false;
}

void gui::TextureSelector::updateKeyTime(const float &dt)
{
    if(this->keyTime < keyTimeMax){
        this->keyTime += 10.f * dt;
    }
}


bool gui::TextureSelector::update(const sf::Vector2i& mouse_pos_window, const float& dt)
{
    this->updateKeyTime(dt);
    this->hideBtn->update(mouse_pos_window, dt);

    if(this->hideBtn->isPressed() && this->getKeyTime()){
        if(this->hidden == true){
            this->hidden = false;
        }
        else{
            this->hidden = true;
        }
    }

    if(!this->hidden){

        this->active = false;

        if(this->bounds.getGlobalBounds().contains(static_cast<sf::Vector2f>(mouse_pos_window))){
            
        this->active = true;
        

        this->mousePosGrid.x = (mouse_pos_window.x - static_cast<int>(this->bounds.getPosition().x)) / static_cast<unsigned>(this->gridSize);
        this->mousePosGrid.y = (mouse_pos_window.y - static_cast<int>(this->bounds.getPosition().y)) / static_cast<unsigned>(this->gridSize);
        
        this->selector.setPosition(
            this->bounds.getPosition().x + this->mousePosGrid.x * this->gridSize,
            this->bounds.getPosition().y + this->mousePosGrid.y * this->gridSize
            );
            //Update Texture rect
            this->textureRect.left = static_cast<int>(this->mousePosGrid.x * this->gridSize);
            this->textureRect.top = static_cast<int>(this->mousePosGrid.y * this->gridSize);
            this->textureRect.width = static_cast<int>(this->gridSize);
            this->textureRect.height = static_cast<int>(this->gridSize);

        }
    }
    return false;
}

void gui::TextureSelector::render(sf::RenderTarget &target)
{
    

    if(!this->hidden){
        target.draw(this->bounds);
        target.draw(this->sheet);
        if(this->active){
            target.draw(this->selector);
        }


    }
    this->hideBtn->render(target);
    
}

//--===================================== Layout =======================================================

gui::Layout::Layout(float x, float y, std::string type, float spacing, float margins,float spacing2, std::vector<gui::UIElement*> elements)
{
    this->type = ui_types::LAYOUT;
    this->pos.x = x;
    this->pos.y = y;
    this->spacing = spacing;
    this->spacing2 = spacing2;
    this->margins = margins;
    this->contents = elements;
    if(type == "vert_grid"){
        this->type = layout_types::VERT_GRID;
    }
    else if(type == "horiz_grid"){
        this->type = layout_types::HORIZ_GRID;
    }
    else if(type == "vert_pad"){
        this->type = layout_types::VERT_PAD;
    }
    else if(type == "horiz_pad"){
        this->type = layout_types::HORIZ_PAD;
    }
    else if(type == "vert_size"){
        this->type = layout_types::VERT_SIZE;
    }
    else if(type == "horiz_size"){
        this->type = layout_types::HORIZ_SIZE;
    }
    else{
        this->type = layout_types::HORIZ_GRID;
    }

}

gui::Layout::~Layout()
{
}


//Accessors

const int gui::Layout::getValue() const
{
    return 0;
}

const sf::Vector2f &gui::Layout::getPosition()
{
    return this->pos;
}

const sf::Vector2f gui::Layout::getSize()
{
   this->size.x = 0;
   this->size.y = 0;

    if(type == layout_types::VERT_GRID){
        this->size.y = (this->spacing * static_cast<float>(this->contents.size()) + this->contents.back()->getSize().y);
        this->size.y -= this->spacing;
        for(auto &i : this->contents){
            if(this->size.x < i->getSize().x){
                this->size.x = i->getSize().x;            
            }
           
        }
    }
    else if(type == layout_types::HORIZ_GRID){
        this->size.x = (this->spacing * static_cast<float>(this->contents.size()) + this->contents.back()->getSize().x);
        this->size.x -= this->spacing;
        for(auto &i : this->contents){
            if(this->size.y < i->getSize().y){
                this->size.y = i->getSize().y;            
            }
            
        }
        
    }
    else if(type == layout_types::VERT_PAD){
        for(int i = 0; i < this->contents.size(); i++){
            if(this->size.x < this->contents.at(i)->getSize().x){
                this->size.x = this->contents.at(i)->getSize().x;
            }
            this->size.y += this->contents.at(i)->getSize().y;
             if(i != this->contents.size() -1){
                 this->size.y += this->spacing;
             }
        } 
    }
    else if(type == layout_types::HORIZ_PAD){
        for(int i = 0; i < this->contents.size(); i++){
            if(this->size.y < this->contents.at(i)->getSize().y){
                this->size.y = this->contents.at(i)->getSize().y;
            }
            this->size.x += this->contents.at(i)->getSize().x;
             if(i != this->contents.size() -1){
                 this->size.x += this->spacing;
             }
        } 
    }
    else if(type == layout_types::HORIZ_SIZE){
        for(int i = 0; i < this->contents.size(); i++){
            if(this->size.y < this->contents.at(i)->getSize().y){
                this->size.y = this->contents.at(i)->getSize().y;
            }
        } 
        this->size.x = (this->spacing + this->margins)*this->contents.size();
        this->size.x -= this->margins;
    }
    else if(type == layout_types::VERT_SIZE){
        for(int i = 0; i < this->contents.size(); i++){
            if(this->spacing2 == 0){
                if(this->size.x < this->contents.at(i)->getSize().x){
                    this->size.x = this->contents.at(i)->getSize().x;
                }
            }else{this->size.x = this->spacing2;}

            this->size.y = (this->spacing + this->margins) * this->contents.size();
            this->size.y -= this->margins;
        } 
    }
    
    
    
    return this->size;
}

// Modifiyers
void gui::Layout::setPosition(const float x, const float y)
{
    this->pos.x = x;
    this->pos.y = y;
    calcPos();
    
}

void gui::Layout::setSize(const float width, const float height)
{
    if(this->type == layout_types::HORIZ_GRID){
        float nWidth = width - this->contents.back()->getSize().x;
        nWidth = nWidth/this->contents.size() - 1;
        this->spacing = nWidth;
        calcPos();
       
    }
    else if(this->type == layout_types::VERT_GRID){
        float nHeight = this->contents.back()->getSize().y;
        nHeight = nHeight/(this->contents.size()-1);
        this->spacing = nHeight;
       
    }
}

void gui::Layout::calcPos()
{
    bool start = false;
    sf::Vector2f currPos = this->pos;
    if(this->type == layout_types::HORIZ_GRID){
        for(int i = 0; i < this->contents.size(); i++){
            this->contents.at(i)->setPosition(this->pos.x + (this->spacing * i), this->pos.y);
        }
    }
    else if(this->type == layout_types::VERT_GRID){
        for(int i = 0; i < this->contents.size(); i++){
            this->contents.at(i)->setPosition(this->pos.x, this->pos.y + this->spacing * i);
        }
    }
    else if(this->type == layout_types::HORIZ_PAD){
        for(int i = 0; i < this->contents.size(); i++){
            
            if(!start){
                this->contents.at(i)->setPosition(currPos.x , this->pos.y );
                currPos.x = currPos.x + this->contents.at(i)->getSize().x;
                start = true;
            }
            else{
                this->contents.at(i)->setPosition(currPos.x + this->spacing , this->pos.y );
                currPos.x = currPos.x + this->spacing + this->contents.at(i)->getSize().x;
            }
        }
    }
    else if(this->type == layout_types::VERT_PAD){
        for(int i = 0; i < this->contents.size(); i++){

            if(!start){
                this->contents.at(i)->setPosition(this->pos.x ,  currPos.y  );
                currPos.y = currPos.y + this->contents.at(i)->getSize().y;
                start = true;
            }
            else{
                this->contents.at(i)->setPosition(this->pos.x ,  currPos.y + this->spacing );
                currPos.y = currPos.y + this->spacing + this->contents.at(i)->getSize().y;
            }
        }
    }
    else if(this->type == layout_types::HORIZ_SIZE){
        for(int i = 0; i < this->contents.size(); i++){
            if(this->spacing2 == 0){
                this->contents.at(i)->setSize(this->spacing, this->contents.at(i)->getSize().y);
            }
            else{
                this->contents.at(i)->setSize(this->spacing, this->spacing2);
            }
            if(!start){
                this->contents.at(i)->setPosition(this->pos.x, this->pos.y);
                currPos.x = currPos.x + this->contents.at(i)->getSize().x;
                start = true;
            }
            else{
                this->contents.at(i)->setPosition(currPos.x + this->margins ,this->pos.y);
                currPos.x = currPos.x + this->spacing + this->contents.at(i)->getSize().x;
            }
        }
    }
    else if(this->type == layout_types::VERT_SIZE){
        for(int i = 0; i < this->contents.size(); i++){ 
            if(this->spacing2 == 0){
                this->contents.at(i)->setSize(this->contents.at(i)->getSize().x, this->spacing);
            }
            else{
                this->contents.at(i)->setSize(this->spacing2, this->spacing);
            }
            if(!start){
                this->contents.at(i)->setPosition(this->pos.x, currPos.y );
                currPos.y = currPos.y + this->spacing;
                start = true;
            }
            else{
                this->contents.at(i)->setPosition(this->pos.x, currPos.y + this->margins);
                currPos.y = currPos.y + this->margins + this->spacing;
            }
        }
    }
}

void gui::Layout::addElement(gui::UIElement *element)
{
    this->contents.push_back(element);
}

//Functions

bool gui::Layout::update(const sf::Vector2i mouse_pos, const float &dt)
{
    return false;
}

void gui::Layout::render(sf::RenderTarget &target)
{
}


