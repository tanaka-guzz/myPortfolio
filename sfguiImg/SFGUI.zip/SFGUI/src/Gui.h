#pragma once

#include <iostream>
#include <vector>
#include<ctime>
#include<sstream>
#include <cmath>
#include <unordered_map>


#include<SFML/System.hpp>
#include<SFML/Window.hpp>
#include<SFML/Graphics.hpp>
#include<SFML/Audio.hpp>

//DEFAULT BUTTON COLORS

#define TEXT_IDLE sf::Color(0,0,0,200)
#define TEXT_HOVER sf::Color(255,255,255,255)
#define TEXT_ACTIVE sf::Color(20,20,20,50)

#define IDLE_COLOR sf::Color(142,142,142,200)
#define HOVER_COLOR sf::Color(200,200,200,255)
#define ACTIVE_COLOR sf::Color(20,20,20,20)

#define OUTLINE_IDLE_COLOR sf::Color::Transparent
#define OUTLINE_HOVER_COLOR sf::Color::Transparent
#define OUTLINE_ACTIVE_COLOR sf::Color::Transparent




//================================GUI Elements ==============================================================
enum button_states {BTN_IDLE = 0, BTN_HOVER, BTN_ACTIVE};
enum layout_types {VERT_GRID = 0, HORIZ_GRID, VERT_PAD, HORIZ_PAD,VERT_SIZE, HORIZ_SIZE };

enum ui_types {TEXT = 0,BUTTON,IBUTTON,CHECKBOX,TOGGLE,DROPDOWN,RADIOLIST,SLIDER,PANNEL,LAYOUT};

namespace gui{
    class UIElement;

    const float p2pX(const float percent, const sf::VideoMode& vm); //percent of screen to pixel value x
    const float p2pY(const float percent, const sf::VideoMode& vm); //percent of screen to pixel value y
    void move(const float x, const float y, gui::UIElement* element);
    const unsigned calCharSize( const sf::VideoMode& vm, const unsigned modifiyer = 60);
    void align(std::string axis, sf::IntRect base, gui::UIElement* element);
    void align(std::string axis, sf::VideoMode& vm, gui::UIElement* element);
    

class UIElement{
private:
    float keyTime;
    float keyTimeMax;
    
protected:
    int type = 0;

public:
    UIElement();
    virtual ~UIElement();

    //Accessors
    const bool getKeyTime();
    const int getType(){return this->type;}
    virtual const bool isPressed() const{return false;}
    virtual const int getValue() const = 0;

    virtual const sf::Vector2f& getPosition() = 0;
    virtual const sf::Vector2f getSize() = 0;

    //Modifiyers
    virtual void setPosition(const float x,const float y) = 0;
    virtual void setSize(const float width,const float height) = 0;

    //Functions
    void updateKeyTime(const float& dt);


    virtual bool update(const sf::Vector2i mouse_pos,  const float& dt) = 0;
    virtual void render(sf::RenderTarget& target) = 0;

};



// Main Elements
class Text
    :public gui::UIElement
{
private:
    sf::Font& font;
    sf::Text text;
    int charSize;
    std::string string;
    sf::Color textColor;
    sf::RectangleShape backGround;


public:
    Text(float x,float y,sf::Font& font,int char_size, std::string in_string, sf::Color text_color = sf::Color(0,0,0,255));
    virtual ~Text();

    //Accessors
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);

    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);



};

class Button
    :public gui::UIElement
{
private:
    short unsigned buttonState;
    short unsigned id;

    bool pressed;
    bool hover;
    sf::RectangleShape shape;
    sf::Font& font;
    sf::Text text;
    unsigned characterSize;

    gui::Button* templateBtn;

    sf::Color textIdleColor;
    sf::Color textHoverColor;
    sf::Color textActiveColor;

    sf::Color idleColor;
    sf::Color hoverColor;
    sf::Color activeColor;

    sf::Color outlineIdleColor;
    sf::Color outlineHoverColor;
    sf::Color outlineActiveColor;



public:
    Button(float x, float y, float width, float height,
        sf::Font& font, std::string text,unsigned character_size,
        sf::Color text_idle_color = TEXT_IDLE, sf::Color text_hover_color = TEXT_HOVER, sf::Color text_active_color = TEXT_ACTIVE,
        sf::Color idle_color = IDLE_COLOR,sf::Color hover_color = HOVER_COLOR,sf::Color active_color = ACTIVE_COLOR,
        sf::Color outline_idle_color = OUTLINE_IDLE_COLOR,sf::Color outline_hover_color = OUTLINE_HOVER_COLOR,sf::Color outline_active_color = OUTLINE_ACTIVE_COLOR, 
        short unsigned id = 0);
    Button(float x, float y, float width, float height, std::string text, Button* buttonStyle, short unsigned id = 0);
    virtual ~Button();


    //Accessors
    const bool isPressed() const;
    const std::string getText() const;
    const short unsigned& getId() const;
    const sf::Vector2f getSize();
    const sf::Vector2f& getPosition();
    const int getValue() const;
    const sf::Color& getColor(int index);
    sf::Font& getFont();
    const unsigned& getCharSize();

    //Modifiers
    void setPosition(const float x, const float y);
    void setSize(const float width,const float height);//!!!!!!!!!!

    void setText(const std::string& text);
    void setId(const short unsigned id);
    void changeBtnColor(sf::Color idle, sf::Color hover, sf::Color active);

    //Functions
    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);


};

class IButton
    : public gui::UIElement
{
private:
    short unsigned buttonState;
    short unsigned id;

    bool pressed;
    bool hover;

    sf::Sprite sprite;
    sf::Texture& idleTex;
    sf::Texture& hoverTex;
    sf::Texture& activeTex;





public:
    IButton(const float x, const float y, sf::Texture& idle_tex, sf::Texture& hover_tex, sf::Texture& active_tex );
    virtual ~IButton();

    //Accessors
    const bool isPressed() const;
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);//!!!!!!!!!!

    //Functions
    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);

};

class CheckBox
    :public gui::UIElement
{
private:
    gui::Button* container;
    sf::RectangleShape checkBox;
    bool value;


public:
    CheckBox(float x, float y, float size, sf::Font& font, sf::Color container = sf::Color(230,230,230,255), sf::Color check_color = sf::Color(10,10,10,200), bool value = false);
    virtual ~CheckBox();

    //Accessors
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);
    
    //Functions
    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);

};

class ToggleSwitch
    : public gui::UIElement
{
private:
    sf::RectangleShape container;
    gui::Button* button;

    bool value;
    float pad; 


public:
    ToggleSwitch(const float x, const float y, const float width, const float height, sf::Font& font);
    virtual ~ToggleSwitch();

    //Accessors
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);
    

    //Functions
    bool update(sf::Vector2i mouse_pos, const float& dt);
    void render(sf::RenderTarget& target);

};

class DropDownList
    : public gui::UIElement
{
private:
    sf::Font& font;
    gui::Button* activeElement;
    std::vector<gui::Button*> list;
    bool showList;
    float height;
    unsigned noOfElements;
    
public:
    DropDownList(float x, float y,float width, float height,sf::Font& font, std::string List[],unsigned no_of_elements,unsigned default_index = 0);
    DropDownList(float x, float y,float width, float height, std::string List[],unsigned no_of_elements,gui::Button* template_btn,unsigned default_index = 0);
    ~DropDownList();

    //Accesors
    const short unsigned& getActiveElementId() const;
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();
    const int getType();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);

    //Functions
    bool update(const sf::Vector2i mouse_pos, const float& dt);
    void render(sf::RenderTarget& target);

};

class RadioList
    :public gui::UIElement
{
private:
    sf::Font& font;
    std::vector<gui::Button*> list;
    float spacing;
    int activeId;
    float btnWidth;
    float btnHeight;


public:
    RadioList(float x, float y, float width, float height,sf::Font& font, std::string List[], unsigned no_of_elements,unsigned default_index = 0);
    RadioList(float x, float y, float width, float height, std::string List[], unsigned no_of_elements,gui::Button* template_btn,unsigned default_index = 0);
    virtual ~RadioList();

    //Accessors
    const int& getActiveId() const;
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();
    

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);

    //Functions
    bool update(const sf::Vector2i mouse_pos, const float& dt);
    void render(sf::RenderTarget& target);
};

// class IRadioList
//     :public gui::UIElement
// {
// private:
//     std::vector<gui::IButton*> list;
//     float spacing;
//     int activeId;
//     float btnWidth;
//     float btnHeight;

// public:
//     IRadioList(float x, float y,  std::vector<std::vector<*sf::Texture>> textures, unsigned no_of_elements,unsigned default_index = 0);
//     virtual ~IRadioList();

//     //Accessors
//     const int& getActiveId() const;
//     const int getValue() const;
//     const sf::Vector2f& getPosition();
//     const sf::Vector2f getSize();
    

//     //Modifiyers
//     void setPosition(const float x,const float y);
//     void setSize(const float width,const float height);

//     //Functions
//     bool update(const sf::Vector2i mouse_pos, const float& dt);
//     void render(sf::RenderTarget& target);


// };

class Slider
    : public gui::UIElement
{
private:
    float minValue;
    float maxValue;
    float currValue;
    float prevValue;

    bool isHeld;

    short unsigned buttonState;

    sf::RectangleShape sliderBar;
    sf::RectangleShape sliderButton;



public:
    Slider(float x, float y, float width, float height, sf::Color color, float min_value, float max_value, float start_value);
    virtual ~Slider();

    //Accessors
    const int getValue() const;
    void setValue(int value);
    bool isPressed();
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);
   

    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);

};

class Pannel
{
private:
    int type;
    sf::RectangleShape container;
    sf::RenderTexture& containerRender;
    sf::Texture outputTexture;
    sf::RectangleShape topBar;

    bool prevLeftMose;
    sf::Vector2f beforClick;
    bool hidden = false;
    bool active = false;
    bool isHeld = false;

   
    


public:
    Pannel(const float x, const float y, const float width, const float height, sf::Font& font, std::string title, const int char_size, sf::RenderTexture& pannel_render);
    virtual ~Pannel();

    //Accessors
    const bool& getActive();
    const int getValue() const {return 0;}
    const sf::Vector2f getPosition() const;

    //Mofidiyers
    void toggleHidden();
    
    

    //Functions
    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);


};

class TextureSelector{
private:
    float keyTime;
    const float keyTimeMax;
    float gridSize;
    bool active;
    bool hidden;

    gui::Button* hideBtn;
    std::string hideBtnText;
   

    sf::RectangleShape bounds;
    sf::Sprite sheet;
    sf::RectangleShape selector;
    sf::Vector2u mousePosGrid;
    sf::IntRect textureRect;



public:
    TextureSelector(float x,float y,float width, float height,float grid_size,const sf::Texture* texture_sheet,sf::Font& font);
    virtual ~TextureSelector();

    //Modifiers
    void toggleHidden();

    //Accessors
    const bool getKeyTime();
    void updateKeyTime(const float& dt);
    const bool& getActive();
    const sf::IntRect& getTextureRect() const;


    //Functions
    bool update(const sf::Vector2i& mouse_pos_window, const float& dt);
    void render(sf::RenderTarget& target);

};

class Layout
: public gui::UIElement
{
private:
    sf::Vector2f pos;
    unsigned type;
    float spacing;
    float margins;
    std::vector<gui::UIElement*> contents;

    float spacing2;
    sf::Vector2f size;

public:
    Layout(float x, float y, std::string = "vert_grid", float spacing = 0, float margins = 0,float spacing2 = 0, std::vector<gui::UIElement*> elements = {});
    virtual ~Layout();

    //Accessors
    const int getValue() const;
    const sf::Vector2f& getPosition();
    const sf::Vector2f getSize();

    //Modifiyers
    void setPosition(const float x,const float y);
    void setSize(const float width,const float height);
    void calcPos();
    void addElement(gui::UIElement* element);

    //Functions
    bool update(const sf::Vector2i mouse_pos,  const float& dt);
    void render(sf::RenderTarget& target);
};

template<typename T>
class UIDictionary{
private:
    std::unordered_map<std::string, T> elements;

    std::unordered_map<std::string, sf::RenderTexture> pannelUi;

public:
    UIDictionary();
    virtual ~UIDictionary();

    void add(std::string key, T element);
    void remove(std::string key,T element);
    T&   at(std::string key);

    void clear();
    bool update(sf::Vector2i mouse,const float& dt);
    void render(sf::RenderTarget& target);

};


//--=========================UIDictionary=========================================
template <typename T>
inline UIDictionary<T>::UIDictionary()
{
}

template <typename T>
inline UIDictionary<T>::~UIDictionary()
{
}
template <typename T>
inline void UIDictionary<T>::add(std::string key, T element)
{
    this->elements[key] = element;
}

template <typename T>
inline void UIDictionary<T>::remove(std::string key,T element)
{
   
    for (auto it = this->elements.cbegin(); it != elements.cend(); ) // no "++"!
    {
        if (it->first == "key")  
        {
            this->element.erase(it++);
        }
        else
        {
            ++it;
        }
    }
}

template <typename T>
inline T &UIDictionary<T>::at(std::string key)
{
    return this->elements.at(key);
}

template <typename T>
inline void UIDictionary<T>::clear()
{
    for(auto &i : this->elements){
        delete i.second;
    }
}

template <typename T>
inline bool UIDictionary<T>::update(sf::Vector2i mouse, const float& dt)
{
    for(auto &i : this->elements){
        
        if(i.second->getType() == ui_types::DROPDOWN){
            if(i.second->update(mouse,dt)){
                return true;
            }
        }
    }   
    for(auto &i : this->elements){
        
        if(i.second->getType() != ui_types::DROPDOWN){
            if(i.second->update(mouse,dt)){
                return true;
            }
        }
    }  

    return false;
}
template <typename T>
inline void UIDictionary<T>::render(sf::RenderTarget &target)
{
    for(auto &i : this->elements){
        if(i.second->getType() != ui_types::DROPDOWN){
            i.second->render(target);
        }
    }
    for(auto &i : this->elements){
        if(i.second->getType() == ui_types::DROPDOWN){
            i.second->render(target);
        }
    }
}
}